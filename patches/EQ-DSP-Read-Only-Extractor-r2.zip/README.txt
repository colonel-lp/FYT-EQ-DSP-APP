EQ & DSP READ-ONLY EXTRACTOR r2
Scripts revised 25 October 2026

PURPOSE AND COMPATIBILITY
Collect static files used for the DSP/Loudness/crossover service, Visualizer
4096/32768 and AUX/audio-path investigations. No system files, DSP registers,
mixer values, routing or dump properties are changed. No raw audio, user
settings, partition images or complete package database are exported.

USB-EXTRACT-DSP contains alternative lsec6315update, lsec6316update,
lsec6521update and lsec6523update binaries supplied by the owner. Presence of
a trigger is NOT proof that it is compatible with a head unit. Use only the
trigger verified for that unit's firmware/update procedure; do not select by
filename similarity or try different updaters until one runs. A working
trigger does not establish that our DSP/Visualizer patches support that unit.
The additional platforms have not been physically verified by this revision.

PREPARATION AND RUN
1. Use stable vehicle power and keep the unit's matching recovery firmware.
2. Use an otherwise empty FAT32 USB drive with adequate free space. Copy the
   CONTENTS of USB-EXTRACT-DSP to its root, not the enclosing folder.
3. Leave ONLY the known-compatible lsec...update binary at the USB root;
   remove the other alternative trigger binaries from this USB. Keep the
   eqdsp-dsp-extractor and lsec_updatesh folders, including all three wrappers
   (lsec.sh, 7862lsec.sh and 8581lsec.sh). They launch the same collector.
   Do not mix any firmware images, patch/install/restore payload or launcher.
4. Insert this USB and follow that unit's established offline lsec procedure.
   Do not interrupt power. The scripts do not mount/unlock partitions,
   acquire root or alter permissions; the updater must supply access.
5. After completion/reboot, open the newly created
   eqdsp-dsp-extract-r2-YYYYMMDD-HHMMSS folder on the USB. A suffix prevents
   overwriting a run made in the same second. Keep the complete folder.
6. Read RESULT.txt and extraction.log. COMPLETE means available selected
   inputs were copied, not that every optional file exists or any patch is
   compatible. PARTIAL/exit 1 means a copy/hash/metadata/mixer limitation;
   retain the output and investigate the stated reason. Exit 2/no output can
   mean that the payload/root could not be located. Never bypass a mismatch.
   No output can also mean the updater did not invoke the script.

USB LOCATION
Each wrapper first uses its own procedure directory, then a supplied USB-root
argument or the current USB directory, then a bounded search of common
/storage and /mnt USB locations.
Only an existing matching payload is accepted. Ambiguous roots stop; leave
only one extractor USB connected. Nothing is mounted automatically.
A different mount can be supplied in a known root-capable Android shell:
  /system/bin/sh /actual/USB/eqdsp-dsp-extractor/extract.sh /actual/USB
This does not gain root or make an incompatible updater usable.

COLLECTION
- Selected com.syu.ms, com.syu.eq and com.syu.av code: active/factory APKs,
  splits, package-local native libraries and available ODEX/VDEX companions.
  Registered /data/app and adopted-storage app code paths are supported too.
  Exact package paths are read from packages.xml (including multiline tags
  and factory updated-package entries); the database itself is not copied.
  Named factory files are also checked. Missing/encrypted data is reported;
  fallback names cannot guarantee discovery of an arbitrarily renamed APK.
- Known system/vendor/OEM/product/system_ext/ODM and system-as-root aliases:
  32/64-bit Visualizer, media/audio framework, primary/policy/audio HAL,
  dump/gain helpers, libsqlcontrol/libjni_spectrum and SYU/FYT framework JARs.
- Build/default/FYT properties; audio/effects/policy/mixer/tiny_hw/codec_pga
  configurations and known policy include directories; audioserver.
- Mount/ALSA inventory, readable PCM status/hw_params and sound-node metadata.
  Optional tinymix card 0/1 LISTS require existing timeout and tinymix tools:
  each command has a 3-second KILL deadline and a 64-block output limit.
  These updater snapshots do not show normal Android playback routing.
- source-files.tsv maps copied inputs to flattened filenames. files.sha256
  fingerprints copied payloads and optional mixer reports (not the active log
  or manifests). Missing SHA-256 support is reported as PARTIAL. Reports may
  include build/device identifiers and paths: review before sharing manually.
  Nothing is uploaded automatically.

LIMITS AND FAILURES
Commands/files differ by firmware. Missing optional paths are expected and
logged. Core service/package metadata, copying and hashing failures are not
silently described as a complete extraction. A full output folder, permissions
or interrupted power can prevent even RESULT.txt from being saved; retain
the updater error/log and any partial folder.

This collection covers the known static inputs, not every future patch.
Live Android/Line In/silence comparisons, app Diagnostics/register readback,
physical audio measurements and patch-specific CHECK/signature verification
remain separate tests. No pm/dumpsys/service calls or unknown JNI functions
are invoked. The previously observed hanging audio_flinger dumps are avoided.

No APK, native binary, trigger binary or ZIP is built/modified by this script
revision. The owner must recreate the downloadable archive from the updated
folder; its download catalogue size/SHA-256 must then be updated to the real
archive. No system-file restore is required for extraction alone.
