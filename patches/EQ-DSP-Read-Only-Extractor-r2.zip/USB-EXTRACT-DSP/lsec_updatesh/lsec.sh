#!/system/bin/sh
/system/bin/sh /storage/sdcard1/eqdsp-dsp-extractor/extract.sh
