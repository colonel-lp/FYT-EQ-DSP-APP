#!/usr/bin/env python3
"""Execute the EXACT patched guard bytes in freestanding Linux x86 harnesses.

Does not load Android libraries or simulate Android runtime/device behaviour.
Only the native guard, entry detour, and relocated prologue are executed.
"""
import json
from pathlib import Path
import subprocess
import struct
import tempfile

ROOT = Path(__file__).resolve().parents[1]
manifest = json.loads((ROOT/'PATCH-MANIFEST.json').read_text())
count = 0
def emulate(exe,bits):
    import unicorn as u
    from unicorn import x86_const as x
    data=exe.read_bytes()
    if bits==32:
        start,phoff=struct.unpack_from('<II',data,24)
        stride,total=struct.unpack_from('<HH',data,42)
    else:
        start,phoff=struct.unpack_from('<QQ',data,24)
        stride,total=struct.unpack_from('<HH',data,54)
    cpu=u.Uc(u.UC_ARCH_X86,u.UC_MODE_32 if bits==32 else u.UC_MODE_64)
    cpu.mem_map(0x30000,0x1d0000)
    cpu.mem_map(0x1000000,0x10000)
    for i in range(total):
        pos=phoff+i*stride
        if bits==32:
            kind,off,va,_,size,_,_,_=struct.unpack_from('<8I',data,pos)
        else:
            kind,_,off,va,_,size,_,_=struct.unpack_from('<II6Q',data,pos)
        if kind==1 and size: cpu.mem_write(va,data[off:off+size])
    cpu.reg_write(x.UC_X86_REG_ESP if bits==32 else x.UC_X86_REG_RSP,0x100fff0)
    result=[]
    def stop(machine,*args):
        number=machine.reg_read(x.UC_X86_REG_EAX)
        assert number==(1 if bits==32 else 60)
        result.append(machine.reg_read(x.UC_X86_REG_EBX if bits==32 else x.UC_X86_REG_EDI))
        machine.emu_stop()
    if bits==32: cpu.hook_add(u.UC_HOOK_INTR,stop)
    else: cpu.hook_add(u.UC_HOOK_INSN,stop,None,1,0,x.UC_X86_INS_SYSCALL)
    cpu.emu_start(start,0,count=200000)
    assert result==[0],f'emulated x86-{bits} guard failed: {result}'
with tempfile.TemporaryDirectory(prefix='eqdsp-native-test-') as tmp:
    tmp = Path(tmp)
    for info in manifest['files'][:2]:
        bits = info['bits']
        entry = info['patches'][-1]
        guard = info['patches'][-2]
        entry_va = int(entry['virtual_address'],16)
        guard_va = int(guard['virtual_address'],16)
        base = 0x40000 if bits == 32 else 0x80000
        for size in (128,256,512,1024,2048,4096):
            expected = 123 if size<=1024 else -22
            value = 0xa5 if size<=1024 else 0
            if bits == 32:
                setup = f'''mov dword ptr [context+0xf4], {size}
                    push 0
                    push offset buffer
                    push offset context
                    call {entry_va}
                    add esp,12'''
                check = f'''cmp eax,{expected}
                    jne failed
                    mov ecx,{size}
                check_loop:
                    cmp byte ptr [buffer+ecx-1],{value}
                    jne failed
                    dec ecx
                    jnz check_loop
                    cmp byte ptr [buffer-1],0x5a
                    jne failed
                    cmp byte ptr [buffer+{size}],0x5a
                    jne failed
                    xor ebx,ebx
                    jmp done
                failed: mov ebx,1
                done: mov eax,1
                    int 0x80'''
                legacy = 'pop edi\n pop ebx\n pop ebp\n mov eax,123\n ret'
            else:
                setup = f'''mov dword ptr [rip+context+0x160],{size}
                    lea rdi,[rip+context]
                    lea rsi,[rip+buffer]
                    xor edx,edx
                    call {entry_va}'''
                check = f'''cmp eax,{expected}
                    jne failed
                    lea rdx,[rip+buffer]
                    mov ecx,{size}
                check_loop:
                    cmp byte ptr [rdx+rcx-1],{value}
                    jne failed
                    dec ecx
                    jnz check_loop
                    cmp byte ptr [rdx-1],0x5a
                    jne failed
                    cmp byte ptr [rdx+{size}],0x5a
                    jne failed
                    xor edi,edi
                    jmp done
                failed: mov edi,1
                done: mov eax,60
                    syscall'''
                legacy = 'pop r15\n pop rbp\n mov eax,123\n ret'
            def byte_directive(hexstr):
                return '.byte '+','.join('0x'+hexstr[i:i+2] for i in range(0,len(hexstr),2))
            asm = f'''.intel_syntax noprefix
                .section .text
                .global _start
                _start:
                {setup}
                {check}
                .org {guard_va-base}
                {byte_directive(guard['after'])}
                .org {entry_va-base}
                {byte_directive(entry['after'])}
                {legacy}
                .section .data
                context: .fill 512,1,0
                .byte 0x5a
                buffer: .fill {size},1,0xa5
                .byte 0x5a
                .section .note.GNU-stack,"",@progbits
            '''
            src, obj, exe = [tmp/f'test.{suffix}' for suffix in ('S','o','elf')]
            src.write_text(asm)
            subprocess.run(['as','--'+str(bits),'-o',str(obj),str(src)],check=True)
            subprocess.run(['ld','-m','elf_i386' if bits==32 else 'elf_x86_64',
                            '-Ttext',hex(base),'-o',str(exe),str(obj)],check=True)
            # Execute on host where supported; always verify in Unicorn too.
            if bits==64: subprocess.run([str(exe)],check=True,timeout=5)
            emulate(exe,bits)
            count += 1
print(f'PASS: {count} emulated guard/prologue/canary cases; 6 also executed natively on x86_64')
