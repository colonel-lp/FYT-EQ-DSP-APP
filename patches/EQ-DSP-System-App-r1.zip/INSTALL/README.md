# Privileged system-app installer (known working base)

This is the USB/lsec installer used to place EQ & DSP at:

`/system/priv-app/EQDsp/EQDSP.apk`

with the privileged allowlist for `CAPTURE_AUDIO_OUTPUT` and
`MODIFY_AUDIO_ROUTING`. It is the direct USB-logging installer that successfully
installed the app on the reference SC9853i unit; it does **not** clear app data,
uninstall the package, or modify any native audio library.

## USB preparation

1. Build the current project in Android Studio and copy its signed `EQDSP.apk`
   to `eqdsp-privileged/EQDSP.apk`.
2. Copy the **contents** of this directory to the root of a USB drive:
   `lsec_updatesh/lsec.sh`, `eqdsp-privileged/EQDSP.apk`, and
   `eqdsp-privileged/privapp-permissions-com.eqdsp.controller.xml`.
3. Add the known-compatible `lsec6521update` trigger file to the USB root.
   Do not mix this launcher with another lsec script or a firmware package.
4. Run the FYT/lsec updater, allow the unit to reboot, then retain
   `eqdsp-privileged-install.log` from the USB root.

## Important limits

- This installer is specific to the tested Android 8.1 FYT unit and writes
  `/system`. Keep a firmware recovery route and stable power available.
- It verifies copy results with `md5sum` and restores SELinux file labels, but
  it is not an APK signing tool.
- A future Android build must retain package ID `com.eqdsp.controller` and be
  signed with the same key to update the existing app safely.
- Android 8.1 Package Manager can retain stale metadata after an in-place
  system APK replacement. This script is retained as the known working
  privileged-install base; do not use the earlier experimental changing-code-
  path installers, which failed because the lsec environment mounted `/system`
  read-only.
