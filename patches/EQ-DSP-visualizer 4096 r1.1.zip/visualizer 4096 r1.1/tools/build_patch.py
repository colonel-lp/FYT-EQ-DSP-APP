#!/usr/bin/env python3
"""Reproducible, exact-input binary patch. Never operates on the head unit.

Usage: python3 tools/build_patch.py /path/to/eqdsp-visualizer-extract-v2
Requires GNU binutils. Library bytes are copied; inputs are never modified.
"""
import hashlib
import json
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
SPECS = [
    ("system-lib-libmedia.so", "/system/lib/libmedia.so",
     "2ec24e20cb42189ee8f87f9530bb23a37ebbf848289de1de4f171f907ff6bf74",
     32, [(0x8275a, "3d80030000", "3d800f0000", "capture range 128..4096")],
     (0x82df0, "5589e55357", 0x41c00, "x86")),
    ("system-lib64-libmedia.so", "/system/lib64/libmedia.so",
     "8e425947add1ea5f79f0c5ee8ec0fd6ec6459ffe31ea8a732926c22205ed19aa",
     64, [(0xbbcf0, "3d80030000", "3d800f0000", "capture range 128..4096")],
     (0xbc310, "554889e54157", 0x80840, "x86_64")),
    ("vendor-lib-soundfx-libvisualizer.so", "/vendor/lib/soundfx/libvisualizer.so",
     "98e223721b75455a09b963eac5a020cb6ce2c865717adc0388afa9cd9a220714",
     32, [(0x11d9, "81fe01040000", "81fe01100000", "effect upper bound 4096"),
          (0x121e, "6800040000", "6800100000", "error log reports new bound")], None),
    ("vendor-lib64-soundfx-libvisualizer.so", "/vendor/lib64/soundfx/libvisualizer.so",
     "3cefb9a2ba9bf07895650ac40b0bc2bd749d6519b7a9af906bbf06b4b9e41298",
     64, [(0x15cd, "81fb01040000", "81fb01100000", "effect upper bound 4096"),
          (0x160a, "41b800040000", "41b800100000", "error log reports new bound")], None),
]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def file_offset(data, addr, length):
    assert data[:4] == b"\x7fELF" and data[5] == 1
    bits = 32 if data[4] == 1 else 64
    if bits == 32:
        phoff, = struct.unpack_from('<I', data, 28)
        entsize, count = struct.unpack_from('<HH', data, 42)
    else:
        phoff, = struct.unpack_from('<Q', data, 32)
        entsize, count = struct.unpack_from('<HH', data, 54)
    for i in range(count):
        pos = phoff + i * entsize
        if bits == 32:
            kind, off, va, _, size, _, flags, _ = struct.unpack_from('<8I', data, pos)
        else:
            kind, flags, off, va, _, size, _, _ = struct.unpack_from('<II6Q', data, pos)
        if kind == 1 and flags & 1 and va <= addr and addr+length <= va+size:
            return off + addr - va
    raise ValueError(f'address {addr:#x} not in file-backed executable segment')

def assemble(arch, addr, scratch):
    bits = '32' if arch == 'x86' else '64'
    src = ROOT / 'tools' / f'fft_guard_{arch}.S'
    obj, elf, raw = [scratch / f'{arch}.{ext}' for ext in ('o', 'elf', 'bin')]
    subprocess.run(['as', '--'+bits, '-o', str(obj), str(src)], check=True)
    subprocess.run(['ld', '-m', 'elf_i386' if bits == '32' else 'elf_x86_64',
                    '-Ttext', hex(addr), '-o', str(elf), str(obj)], check=True)
    subprocess.run(['objcopy', '-O', 'binary', '--only-section=.text', str(elf), str(raw)], check=True)
    return raw.read_bytes()

def main(source):
    source = Path(source)
    entries = []
    built = []
    with tempfile.TemporaryDirectory(prefix='eqdsp-patch-build-') as tmp:
        for filename, target, expected, bits, changes, guard in SPECS:
            original = (source / filename).read_bytes()
            if sha(original) != expected:
                raise ValueError(f'WRONG INPUT: {filename}; no package written')
            if original[4] != (1 if bits == 32 else 2):
                raise ValueError('ELF class mismatch')
            patched = bytearray(original)
            audit = []
            def edit(addr, old, new, reason):
                old, new = bytes.fromhex(old), bytes.fromhex(new)
                assert len(old) == len(new)
                off = file_offset(original, addr, len(old))
                if patched[off:off+len(old)] != old:
                    raise ValueError(f'{filename}: original instruction mismatch at {addr:#x}')
                patched[off:off+len(old)] = new
                audit.append(dict(virtual_address=hex(addr), file_offset=hex(off),
                                  before=old.hex(), after=new.hex(), reason=reason))
            for change in changes:
                edit(*change)
            if guard:
                entry, original_prologue, cave, arch = guard
                code = assemble(arch, cave, Path(tmp))
                edit(cave, (b'\x90'*len(code)).hex(), code.hex(),
                     'packed FFT >1024 returns zeroed output, never enters fixed FFT')
                jmp = b'\xe9' + struct.pack('<i', cave-entry-5)
                jmp += b'\x90' * (len(bytes.fromhex(original_prologue))-len(jmp))
                edit(entry, original_prologue, jmp.hex(), 'direct branch to FFT safety guard')
            allowed = set()
            for change in audit:
                off = int(change['file_offset'],16)
                allowed.update(range(off, off+len(bytes.fromhex(change['before']))))
            assert len(original) == len(patched)
            changed = [i for i,(a,b) in enumerate(zip(original,patched)) if a != b]
            assert set(changed) <= allowed
            entries.append(dict(file=filename, device_path=target, bits=bits,
                                original_sha256=sha(original), patched_sha256=sha(patched),
                                size=len(original), changed_bytes=len(changed), patches=audit))
            built.append((filename, original, patched))
        # All inputs checked before creating either payload.
        for action in ('INSTALL','RESTORE'):
            payload = ROOT / f'USB-{action}' / 'eqdsp-visualizer4096'
            for filename, original, patched in built:
                for kind, data in [('original', original), ('patched', patched)]:
                    dest = payload / kind / filename
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    dest.write_bytes(data)
            source_template = (ROOT/'tools/installer-template.sh').read_text()
            calls = '\n'.join('    "$@" '+e['file']+' '+e['device_path']+' '+
                              e['original_sha256']+' '+e['patched_sha256']+' || return 1'
                              for e in entries)
            script = source_template.replace('@TARGET_CALLS@',calls)
            (payload/'run.sh').write_text(script)
            launcher = ROOT / f'USB-{action}' / 'lsec_updatesh' / 'lsec.sh'
            launcher.parent.mkdir(parents=True,exist_ok=True)
            launcher.write_text('#!/system/bin/sh\n/system/bin/sh /storage/sdcard1/eqdsp-visualizer4096/run.sh '+action.lower()+'\n')
    manifest = {'patch':'EQ-DSP-Visualizer4096-r1','advertised_max_unchanged':1024,
                'opt_in_waveform_max':4096,'native_fft_max':1024,'files':entries}
    (ROOT/'PATCH-MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'result':'BUILT','files':len(entries),'changed_bytes':sum(x['changed_bytes'] for x in entries)},indent=2))

if __name__ == '__main__':
    main(sys.argv[1])
