#!/system/bin/sh
# Invoked by the real shell, not interpreted by lsec's command parser.
# Four exact targets only. No APK, partition, audio policy or DSP writes.
EQDSP_MODE=$1
EQDSP_USB=/storage/sdcard1
EQDSP_PAYLOAD=$EQDSP_USB/eqdsp-visualizer4096
EQDSP_BACKUP=$EQDSP_USB/eqdsp-visualizer4096-backup-r1
EQDSP_LOG=$EQDSP_USB/eqdsp-visualizer4096-$EQDSP_MODE.log
EQDSP_CHANGED=0
EQDSP_STAGING=0
EQDSP_RESULT=FAILED

targets() {
    "$@" system-lib-libmedia.so /system/lib/libmedia.so 2ec24e20cb42189ee8f87f9530bb23a37ebbf848289de1de4f171f907ff6bf74 ca63a0403668e62c6521185604ee7b2ab1da8811b8ab08fbc0261ccdd609bfca || return 1
    "$@" system-lib64-libmedia.so /system/lib64/libmedia.so 8e425947add1ea5f79f0c5ee8ec0fd6ec6459ffe31ea8a732926c22205ed19aa c92d15676705119b787d5301b445ab422bd261b3a54448e44e11bccdcadfe0e5 || return 1
    "$@" vendor-lib-soundfx-libvisualizer.so /vendor/lib/soundfx/libvisualizer.so 98e223721b75455a09b963eac5a020cb6ce2c865717adc0388afa9cd9a220714 f12e3920abd5fb64ff4f1ff8a92e73f5dfae4d5fef91a1ac5de16c41e2bed302 || return 1
    "$@" vendor-lib64-soundfx-libvisualizer.so /vendor/lib64/soundfx/libvisualizer.so 3cefb9a2ba9bf07895650ac40b0bc2bd749d6519b7a9af906bbf06b4b9e41298 c367f0a435921fb0c2dcb67b3a98198bd3cfb8285e4bc474ee20fe156f187133 || return 1
}
fail() { echo "ERROR: $*"; exit 1; }
hash_file() {
    EQDSP_HASH_LINE=$(sha256sum "$1") || return 1
    echo "${EQDSP_HASH_LINE%% *}"
}
check_hash() {
    [ -f "$1" ] && [ ! -L "$1" ] || return 1
    EQDSP_HASH=$(hash_file "$1") || return 1
    [ "$EQDSP_HASH" = "$2" ]
}
verify_target() {
    check_hash "$EQDSP_PAYLOAD/original/$1" "$3" || { echo "Bad original payload: $1"; return 1; }
    check_hash "$EQDSP_PAYLOAD/patched/$1" "$4" || { echo "Bad patched payload: $1"; return 1; }
    [ -f "$2" ] && [ ! -L "$2" ] || { echo "Missing/symlink target: $2"; return 1; }
    EQDSP_CURRENT=$(hash_file "$2") || return 1
    if [ "$EQDSP_CURRENT" != "$3" ] && [ "$EQDSP_CURRENT" != "$4" ]; then
        echo "FIRMWARE MISMATCH: $2 hash $EQDSP_CURRENT"
        return 1
    fi
    [ ! -e "$2.eqdsp4096-r1-stage" ] && [ ! -L "$2.eqdsp4096-r1-stage" ] || return 1
    [ ! -e "$2.eqdsp4096-r1-rollback" ] && [ ! -L "$2.eqdsp4096-r1-rollback" ] || return 1
    echo "VERIFIED: $2 ($EQDSP_CURRENT)"
    ls -lZ "$2"
}
backup_target() {
    # The known extracted originals are also shipped in the restore package.
    if [ -e "$EQDSP_BACKUP/$1" ]; then
        check_hash "$EQDSP_BACKUP/$1" "$3" || return 1
    else
        cp "$EQDSP_PAYLOAD/original/$1" "$EQDSP_BACKUP/$1" || return 1
        check_hash "$EQDSP_BACKUP/$1" "$3" || return 1
    fi
}
prepare_mount() {
    # lsec normally mounts these read-write. Its minimal shell has no awk, so
    # avoid parsing /proc/mounts: attempt the standard remount, then prove that
    # the actual target is writable. A harmless remount failure is acceptable
    # when lsec already supplied the read-write mount.
    mount -o remount,rw "$1" >/dev/null 2>&1 || :
    mkdir "$1/.eqdsp4096-r1-writecheck" || return 1
    rmdir "$1/.eqdsp4096-r1-writecheck" || return 1
}
stage_target() {
    EQDSP_WANTED=$4
    EQDSP_FOLDER=patched
    if [ "$EQDSP_MODE" = restore ]; then EQDSP_WANTED=$3; EQDSP_FOLDER=original; fi
    cp "$EQDSP_PAYLOAD/$EQDSP_FOLDER/$1" "$2.eqdsp4096-r1-stage" || return 1
    check_hash "$2.eqdsp4096-r1-stage" "$EQDSP_WANTED" || return 1
    chown 0.0 "$2.eqdsp4096-r1-stage" || return 1
    chmod 0644 "$2.eqdsp4096-r1-stage" || return 1
    /system/bin/restorecon "$2.eqdsp4096-r1-stage" || return 1
}
commit_target() {
    EQDSP_WANTED=$4
    [ "$EQDSP_MODE" = restore ] && EQDSP_WANTED=$3
    mv -f "$2.eqdsp4096-r1-stage" "$2" || return 1
    /system/bin/restorecon "$2" || return 1
    check_hash "$2" "$EQDSP_WANTED" || return 1
    echo "COMMITTED: $2"
}
rollback_target() {
    # Only called after all payloads and live targets passed initial validation.
    check_hash "$EQDSP_PAYLOAD/original/$1" "$3" || return 1
    cp "$EQDSP_PAYLOAD/original/$1" "$2.eqdsp4096-r1-rollback" || return 1
    check_hash "$2.eqdsp4096-r1-rollback" "$3" || return 1
    chown 0.0 "$2.eqdsp4096-r1-rollback" || return 1
    chmod 0644 "$2.eqdsp4096-r1-rollback" || return 1
    /system/bin/restorecon "$2.eqdsp4096-r1-rollback" || return 1
    mv -f "$2.eqdsp4096-r1-rollback" "$2" || return 1
    /system/bin/restorecon "$2" || return 1
    check_hash "$2" "$3" || return 1
}
rollback_all() {
    # Continue attempting remaining files even if one restoration fails.
    EQDSP_ROLLBACK_FAILED=0
    targets rollback_attempt
    [ "$EQDSP_ROLLBACK_FAILED" = 0 ]
}
rollback_attempt() { rollback_target "$@" || EQDSP_ROLLBACK_FAILED=1; return 0; }
cleanup_target() {
    if [ -f "$2.eqdsp4096-r1-stage" ]; then rm "$2.eqdsp4096-r1-stage"; fi
    if [ -f "$2.eqdsp4096-r1-rollback" ]; then rm "$2.eqdsp4096-r1-rollback"; fi
    return 0
}
finish() {
    EQDSP_EXIT=$?
    trap - 0 1 2 15
    if [ "$EQDSP_EXIT" != 0 ] && [ "$EQDSP_CHANGED" = 1 ]; then
        echo "Installation interrupted/failed. Restoring all four stock libraries."
        if rollback_all; then
            echo "ROLLBACK VERIFIED: all four stock libraries restored."
        else
            echo "CRITICAL: rollback incomplete. Use USB-RESTORE or matching firmware recovery."
        fi
    fi
    if [ "$EQDSP_STAGING" = 1 ]; then targets cleanup_target; fi
    sync
    echo "RESULT: $EQDSP_RESULT; exit $EQDSP_EXIT; $(date)"
    sync
    exit "$EQDSP_EXIT"
}

case "$EQDSP_MODE" in install|restore) ;; *) exit 2;; esac
# Log directly to USB, before any system write. Refuse if that is unavailable.
exec >"$EQDSP_LOG" 2>&1 || exit 1
trap finish 0
trap 'exit 130' 1 2 15
set -x
echo "EQ & DSP Visualizer4096 r1: $EQDSP_MODE; $(date)"
[ "$(id -u)" = 0 ] || fail "Root updater execution required."
command -v sha256sum >/dev/null 2>&1 || fail "sha256sum unavailable; no writes performed."
command -v pidof >/dev/null 2>&1 || fail "Cannot verify offline updater environment."
if pidof system_server audioserver >/dev/null 2>&1; then
    fail "Android audio/framework processes are running. Use the lsec updater, not live Android."
fi
[ -x /system/bin/restorecon ] || fail "restorecon unavailable."
[ "$(getprop ro.product.device)" = sp9853i_1h10 ] || fail "Wrong device."
[ "$(getprop ro.build.version.sdk)" = 27 ] || fail "Requires tested Android 8.1/API 27 firmware."
targets verify_target || fail "Preflight failed; no system files changed."
mkdir -p "$EQDSP_BACKUP" || fail "Cannot create USB backup."
targets backup_target || fail "Backup mismatch or write failure."
sync
prepare_mount /system || fail "System is not writable; stopped."
prepare_mount /vendor || fail "Vendor is not writable; stopped."
EQDSP_STAGING=1
targets stage_target || fail "Staging failed; live libraries untouched."
sync
EQDSP_CHANGED=1
targets commit_target || fail "Commit failed."
sync
EQDSP_CHANGED=0
EQDSP_RESULT=SUCCESS
echo "SUCCESS: $EQDSP_MODE verified. Reboot via the updater to load the libraries."
exit 0
