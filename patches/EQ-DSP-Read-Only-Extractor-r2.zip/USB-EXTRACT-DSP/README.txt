EQ & DSP READ-ONLY EXTRACTOR r2 -- scripts revised 25 October 2026

Read ../README.txt before preparing the USB.

Copy this folder's CONTENTS to an otherwise empty FAT32 USB root.
Leave only the lsec...update binary known to match your unit's firmware.
Keep both folders and all three lsec_updatesh wrappers. Do not mix firmware
images, install/restore payloads or another procedure on this USB.

Wrappers detect the existing payload's USB root; /storage/sdcard1 is no
longer assumed. They do not mount partitions, gain root or validate that a
vendor updater is compatible. Unverified platforms need physical testing.

Return the complete NEW eqdsp-dsp-extract-r2-YYYYMMDD-HHMMSS[-suffix] folder.
Read RESULT.txt, extraction.log, source-files.tsv and files.sha256.
PARTIAL/exit 1 needs investigation; no output can mean launcher/root failure.
Missing optional files are logged. Repeated runs preserve earlier results.

Reads selected service/EQ/AUX code, audio libraries/configs/build properties
and bounded read-only sound snapshots. No system/audio-setting writes,
raw audio or full package database. Offline results do not replace live
Android playback/Line In tests. Review identifiers before manually sharing.

Full preparation, coverage, limitations and recovery: the parent README.txt
in tools/read-only-extractor-r2 (keep it with the downloaded procedure).
