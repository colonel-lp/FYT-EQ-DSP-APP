package com.eqdsp.controller;
import java.util.Arrays;

public class VisualizerSpectrumTest {
    static void check(boolean ok, String message) {
        if (!ok) throw new AssertionError(message);
    }
    static byte[] tone(int size, int rate, double hz, double amplitude) {
        byte[] result=new byte[size];
        for(int i=0;i<size;i++) result[i]=(byte)Math.round(128+amplitude*Math.sin(2*Math.PI*hz*i/rate));
        return result;
    }
    public static void main(String[] args) {
        check(VisualizerSpectrum.calculate(null,44100)==null,"null");
        check(VisualizerSpectrum.calculate(new byte[127],44100)==null,"short");
        check(VisualizerSpectrum.calculate(new byte[4096],0)==null,"rate");
        int cases=0;
        for(int rate:new int[]{44100,48000}) {
            for(int size:new int[]{128,512,1024,2048,4096}) {
                byte[] silence=new byte[size]; Arrays.fill(silence,(byte)128);
                VisualizerSpectrum.Frame frame=VisualizerSpectrum.calculate(silence,rate);
                check(frame.captureSize==size && frame.magnitudes.length==size/2,"shape");
                check(frame.signalRms==0,"silence rms");
                for(float x:frame.magnitudes) check(x==0,"silence bin");
                cases++;
            }
            for(double hz:new double[]{20,40,50,100,200,300,500,800,1000,5000,10000,15000,20000}) {
                VisualizerSpectrum.Frame f=VisualizerSpectrum.calculate(tone(4096,rate,hz,80),rate);
                int peak=1;
                for(int k=2;k<f.magnitudes.length;k++) if(f.magnitudes[k]>f.magnitudes[peak]) peak=k;
                double tolerance=hz<=600?rate/4096.0:rate/1024.0;
                check(Math.abs(peak*(double)rate/4096-hz)<=tolerance,"peak "+hz+" at "+rate);
                for(float x:f.magnitudes) check(Float.isFinite(x)&&x>=0,"finite nonnegative");
                cases++;
            }
            // Coherent bass tone, coherent high tone: amplitude does not drop 4x.
            for(double hz:new double[]{rate*10.0/4096,rate*100.0/1024}) {
                VisualizerSpectrum.Frame f=VisualizerSpectrum.calculate(tone(4096,rate,hz,80),rate);
                float peak=0; for(float v:f.magnitudes) peak=Math.max(peak,v);
                check(Math.abs(peak-80)<1,"window gain "+peak);
                cases++;
            }
            // A stopped signal must not retain audio from a previous callback.
            byte[] silence=new byte[4096]; Arrays.fill(silence,(byte)128);
            for(float v:VisualizerSpectrum.calculate(silence,rate).magnitudes) check(v==0,"stale frame");
            // Newest 1024 samples supply high-frequency transients.
            byte[] onset=new byte[4096]; Arrays.fill(onset,(byte)128);
            byte[] recent=tone(1024,rate,rate*100.0/1024,80);
            System.arraycopy(recent,0,onset,3072,1024);
            float peak=0;for(float v:VisualizerSpectrum.calculate(onset,rate).magnitudes)peak=Math.max(peak,v);
            check(peak>79,"short-window transient response");
            cases++;
        }
        System.out.println("PASS: "+cases+" Java FFT cases plus input/silence checks");
    }
}
