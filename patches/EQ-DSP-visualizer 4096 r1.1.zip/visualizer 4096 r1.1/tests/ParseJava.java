import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.tools.*;
import com.sun.source.util.JavacTask;

/** Syntax-only verification, deliberately not an Android SDK compilation. */
public class ParseJava {
    public static void main(String[] args) throws Exception {
        JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
        DiagnosticCollector<JavaFileObject> errors=new DiagnosticCollector<>();
        try(StandardJavaFileManager fm=compiler.getStandardFileManager(errors,null,null)) {
            List<File> files=new ArrayList<>();
            for(String s:args)files.add(new File(s));
            JavacTask task=(JavacTask)compiler.getTask(null,fm,errors,
                    java.util.Arrays.asList("-proc:none","--release","8"),null,fm.getJavaFileObjectsFromFiles(files));
            task.parse();
            for(Diagnostic<?> d:errors.getDiagnostics()) {
                if(d.getKind()==Diagnostic.Kind.ERROR)throw new AssertionError(d.toString());
            }
            System.out.println("PASS: Java 8 syntax for "+files.size()+" files (not type checking)");
        }
    }
}
