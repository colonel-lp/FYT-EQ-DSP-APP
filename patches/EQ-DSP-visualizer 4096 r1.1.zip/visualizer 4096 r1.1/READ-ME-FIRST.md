# EQ & DSP Visualizer4096 — experimental patch r1.1

Built for the supplied SC9853i Android 8.1/API 27 extraction, dated 23 September
2026. This is NOT a generic Joying patch and has NOT yet been tested on the unit.

Installer revision r1.1 removes the unavailable `awk` dependency found on the
unit's lsec shell. It makes no native-library byte changes. The native patch
has not been proven safe on the reference unit; its installer status and a
successful file hash check must never be confused with a successful runtime
audio test.

## What is included

| Folder/file | Purpose |
| --- | --- |
| `USB-INSTALL` | Ready-made native library patch and `lsec.sh` launcher |
| `USB-RESTORE` | Separate restore launcher and byte-exact stock libraries |
| Repository-root `EQ-DSP-v1.18-beta` project | Current Android Studio source; outputs `EQDSP.apk` |
| `USB-EXTRACT-DSP` | Optional read-only collection of missing Joying service/HAL files |
| `FINDINGS.md` | Evidence, limits, useful discoveries, and future investigation list |
| `PATCH-MANIFEST.json` | Original/patched hashes, addresses, exact changed bytes |
| `tools` / `tests` | Reproducible patch builder, assembly guards, validation tests |

## Before installing

Keep the working firmware recovery files and a copy of this entire package on
your computer. Prepare the restore USB before applying the patch. Use a stable
power supply, stop playback, and keep the volume low for the first test.

This replaces four system/vendor libraries. A failure, interrupted power, or
firmware incompatibility can break audio or prevent normal Android startup.
The restore package depends on the lsec updater remaining usable; it is not a
guaranteed recovery from every failure. The recorded verified-boot property is
`green`; hash checks and previous successful app installation do not prove that
modified native libraries will boot. No verified-boot or SELinux protections are
disabled by this package.

The installer checks the device/API and every target's SHA-256, accepts only
the exact stock or this patch's bytes, requires the offline updater environment,
backs up originals to USB, tests write access to both partitions, stages all
files, and verifies replacements. On a detected commit failure it attempts to
restore all four stock libraries. Unknown firmware files cause a stop.

The complete reference procedures contain the exact original/patched libraries retained from the installed snapshot. Use them only when all device hashes match the manifest. The reproducible builder still refuses any other input hashes.

## Install — two separate parts

1. Open this repository's `source/` project in Android Studio and build the current versioned APK. Install it as
   a normal update using the SAME signing key as the installed app. Keep your
   existing app data/presets/themes; do not uninstall. If Android reports a
   signature mismatch, stop rather than deleting the app. This source package
   does not include your signing key or a precompiled APK.
2. Before applying the system patch, the app should still play normally and report
   1024 samples on this stock firmware. Select **Android Visualizer**, not 0x2
   or 0x3. Save this baseline Diagnostics output.
3. Build the native payload from the output of `USB-EXTRACT-DSP`:
   `python3 "tools/visualizer 4096 r1.1/tools/build_patch.py" /path/to/eqdsp-dsp-extract-r2`.
   This requires GNU binutils and writes the original and patched library
   payloads inside both USB folders only after all four source hashes pass.
4. Copy the CONTENTS of `USB-INSTALL` to the USB root, alongside the SAME known
   compatible `lsec6521update` used successfully on this unit. That updater is
   included in each complete reference procedure; do not substitute another platform's updater. Do not add a firmware ZIP, Allapp.pkg, an old app installer, or
   another `lsec_updatesh` script.
5. Run the updater as before and let it finish/reboot. Do not interrupt power.
6. Keep `eqdsp-visualizer4096-r1.1-install.log` from the USB root. It must end with
   `RESULT: SUCCESS; exit 0`. A success message confirms file installation, not
   runtime audio compatibility.
7. Open EQ & DSP, select Android Visualizer and enable Spectrum. Diagnostics
   should show capture **4096**, bins **2048**, and source describing **4096 bass
   / 1024 treble**. At the usual 44100 Hz, bin spacing is about 10.77 Hz.

If you prefer the established privileged APK updater in
`tools/system-app-installer`, use it in a SEPARATE
update cycle. This native installer neither installs an APK nor alters Package
Manager state. Installing only the native patch with v1.15 will not enable the
full 4096-sample analysis.

## Initial test

- First check that speaker audio continues with Spectrum on, off, and after
  minimising/reopening the app. No audio routing changes are part of this patch.
- Then try 20, 40, 100, 500 Hz and 1, 5, 10, 15, 20 kHz test tones at a modest
  level. For analyser comparison, disable EQ Curve and Post-EQ display.
- Check pause/silence, switching styles, and a few minutes of ordinary music.
- Share the installer log and Diagnostics, plus any visual or playback issue.

The change is intended to improve bass frequency separation, not speaker bass
output or DSP sound quality. The signal remains an 8-bit, mono Android Visualizer
snapshot, not calibrated dBFS/SPL or a measurement of the external DSP's output.
Its 4096-sample bass window spans about 93 ms at 44.1 kHz;
the 1024-sample treble window spans about 23 ms. Callback refresh remains up to
20 times/second. A Hann-windowed tone occupies multiple bins, so 20 Hz will not
be an infinitely thin line. No discontinuous callbacks are concatenated.

## Restore

After building the payload, use a separate USB setup containing the CONTENTS
of `USB-RESTORE` plus your
known compatible `lsec6521update`. Run the updater, reboot and retain
`eqdsp-visualizer4096-r1.1-restore.log`. All four native libraries should match their
original hashes. The current app can stay installed and falls back to stock
capture sizes.

The locally built restore payload contains originals, so it does not depend on Android
starting, an installed EQDSP APK, or the `/cache` partition retaining backups.
If the installer refuses a hash mismatch, or restoration fails, keep the logs
and use the matching firmware recovery process; do not bypass the checks.

## Optional next investigation

Use `USB-EXTRACT-DSP` in a SEPARATE updater run with the same compatible updater.
It only reads selected factory/app files and writes to USB. Zip the resulting
`eqdsp-dsp-extract-r2` folder and send it back. It avoids the `dumpsys` commands
that previously hung. Missing APKs/configs are logged, not guessed.

Do not combine install, restore, and extraction launchers on the same USB.

## Verification completed here

- Exact input SHA-256 and original instructions checked; only listed bytes
  changed. Four ELF files retain their sizes, headers and dynamic dependencies.
- 12 native guard/prologue/buffer-canary cases in x86/x86_64 emulation; six
  x86_64 cases also executed directly on the host.
- 42 Java FFT cases at 44.1/48 kHz plus input/silence checks, including tone
  positions, amplitude correction, treble transient response, and full range.
- Installer simulation: install/reinstall/restore/re-restore, wrong firmware,
  corrupt payload, symlink target, bad backup, remount failure, live Android,
  staging failure, and failure after the first library replacement.
- Shell syntax and Java 8 parsing checked. Full Android APK compilation,
  SELinux/verified-boot operation, and real head-unit audio remain UNTESTED.


## Source procedure log names

INSTALL writes `eqdsp-visualizer4096-r1.1-install.log`; RESTORE writes `eqdsp-visualizer4096-r1.1-restore.log` at USB root. The separate USB-EXTRACT-DSP procedure writes `eqdsp-dsp-extract-r2/eqdsp-dsp-extractor-r2.log`. Library payloads/hashes and legacy backup/staging names are unchanged. Existing public ZIPs retain their bundled scripts/log names until separately repackaged.
