# Signed APK upload required

The owner requested a local download instead of a base64 binary upload.

- Destination: `tools/processing-r4-audio-hooks/USB-INSTALL/eqdsp-loudness/patched.apk`
- Size: **2176210 bytes**
- SHA-256: `0f6b8b69b6d471aa54eb57db21a658c27360ae4b940dd832aa60f6aae14d73c3`
- Signer SHA-256: `c8a2e9bccf597c2fb6dc66bee293fc13f2fc47ec77bc6b2b0d52c11f51192ab8`; v1 and v2 verified.
- Scripts, source and existing factory/updater objects are published separately. INSTALL is incomplete until this exact file is added.
- Preserve the completed APK; do not rebuild merely for publication.
