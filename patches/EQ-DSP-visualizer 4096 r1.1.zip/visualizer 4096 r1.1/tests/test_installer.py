#!/usr/bin/env python3
"""Run the generated installer only against temporary fake device trees.

Mounts, device properties and SELinux are stubs: this tests transaction logic,
not Android updater compatibility or verified boot.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT=Path(__file__).resolve().parents[1]
entries=json.loads((ROOT/'PATCH-MANIFEST.json').read_text())['files']
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def case(name, actions, fault=None):
    with tempfile.TemporaryDirectory(prefix='eqdsp-installer-test-') as tmp:
        base=Path(tmp)
        usb=base/'storage/sdcard1'; usb.mkdir(parents=True)
        payload=usb/'eqdsp-visualizer4096'
        shutil.copytree(ROOT/'USB-INSTALL/eqdsp-visualizer4096',payload)
        for e in entries:
            dest=base/e['device_path'].lstrip('/')
            dest.parent.mkdir(parents=True,exist_ok=True)
            shutil.copyfile(payload/'original'/e['file'],dest)
        mounts=base/'mounts'
        mounts.write_text(f'/fake/system {base}/system ext4 ro 0 0\n/fake/vendor {base}/vendor ext4 ro 0 0\n')
        bindir=base/'bin';bindir.mkdir()
        def stub(name, body):
            p=bindir/name;p.write_text('#!/bin/sh\n'+body+'\n');p.chmod(0o755)
        stub('getprop','case "$1" in ro.product.device) echo sp9853i_1h10;; ro.build.version.sdk) echo 27;; esac')
        stub('pidof','exit '+('0' if fault=='live' else '1'))
        stub('mount','exit '+('1' if fault=='mount' else '0'))
        # The real lsec shell exposes no awk. The installer must not need it.
        stub('awk','exit 127')
        selinux=base/'system/bin/restorecon';selinux.parent.mkdir(parents=True,exist_ok=True)
        selinux.write_text('#!/bin/sh\nexit 0\n');selinux.chmod(0o755)
        script=(payload/'run.sh').read_text()
        for old,new in [('/proc/mounts',str(mounts)),('/storage/sdcard1',str(usb)),
                        ('/system',str(base/'system')),('/vendor',str(base/'vendor'))]:
            script=script.replace(old,new)
        # Confirm no absolute device target survives before executing anything.
        assert '\n    "$@" system-lib-libmedia.so /system' not in script
        run=base/'run.sh';run.write_text(script)
        if fault=='mismatch':
            target=base/entries[0]['device_path'].lstrip('/')
            target.write_bytes(target.read_bytes()+b'x')
        if fault=='payload':
            p=payload/'patched'/entries[0]['file'];p.write_bytes(b'corrupt')
        if fault=='symlink':
            target=base/entries[0]['device_path'].lstrip('/')
            target.unlink();target.symlink_to(payload/'original'/entries[0]['file'])
        if fault=='backup':
            b=usb/'eqdsp-visualizer4096-backup-r1';b.mkdir()
            (b/entries[0]['file']).write_bytes(b'wrong backup')
        if fault=='stage':
            stub('cp','case "$2" in *system/lib64/libmedia.so.eqdsp4096-r1-stage) exit 1;; esac\nexec /bin/cp "$@"')
        if fault=='commit':
            marker=base/'injected'
            stub('mv',f'''case "$2" in *system/lib64/libmedia.so.eqdsp4096-r1-stage)
if [ ! -e "{marker}" ]; then : > "{marker}"; exit 1; fi;; esac
exec /bin/mv "$@"''')
        if fault=='writecheck':
            stub('mkdir','case "$1" in *.eqdsp4096-r1-writecheck) exit 1;; esac\nexec /bin/mkdir "$@"')
        before=[digest(base/e['device_path'].lstrip('/')) for e in entries]
        for action,success in actions:
            p=subprocess.run(['/bin/sh',str(run),action],env={**os.environ,'PATH':str(bindir)+':/usr/bin:/bin'},timeout=20)
            log=(usb/f'eqdsp-visualizer4096-{action}.log').read_text()
            if (p.returncode==0)!=success:
                raise AssertionError(name+' unexpected status\n'+log)
            after=[digest(base/e['device_path'].lstrip('/')) for e in entries]
            if success:
                expected=[e['patched_sha256' if action=='install' else 'original_sha256'] for e in entries]
                assert after==expected,(name,'output hash mismatch')
                assert 'RESULT: SUCCESS' in log
            else:
                assert after==before,(name,'changed live bytes on failure')
                assert 'RESULT: FAILED' in log
            assert not list((base/'system').rglob('*.eqdsp4096-r1-stage'))
            assert not list((base/'vendor').rglob('*.eqdsp4096-r1-stage'))
        print('PASS:',name)

case('install / repeat install / restore / repeat restore',
     [('install',True),('install',True),('restore',True),('restore',True)])
case('mount command fails but lsec mount is already writable', [('install',True)], 'mount')
for fault in ['mismatch','payload','symlink','backup','writecheck','live','stage','commit']:
    case('reject or recover '+fault,[('install',False)],fault)
