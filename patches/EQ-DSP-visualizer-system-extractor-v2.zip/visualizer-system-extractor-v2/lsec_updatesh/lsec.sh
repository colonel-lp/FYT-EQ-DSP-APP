#!/system/bin/sh
/system/bin/sh /storage/sdcard1/eqdsp-extractor-v2/extract-real.sh
