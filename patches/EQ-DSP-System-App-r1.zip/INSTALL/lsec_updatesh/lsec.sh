#!/system/bin/sh
# EQ & DSP v1.13-beta privileged installer with USB logging.
# It copies the supplied APK and allowlist, but stops on a critical failure.

exec > /storage/sdcard1/eqdsp-privileged-install.log 2>&1
set -x

echo "EQ & DSP privileged install logger"
date
id
getprop ro.build.fingerprint
getprop ro.build.version.release
mount

echo "--- USB inputs ---"
ls -l /storage/sdcard1/eqdsp-privileged

if [ ! -f /storage/sdcard1/eqdsp-privileged/EQDSP.apk ]; then
    echo "ERROR: EQDSP.apk is missing from the USB patch folder"
    exit 1
fi

if [ ! -f /storage/sdcard1/eqdsp-privileged/privapp-permissions-com.eqdsp.controller.xml ]; then
    echo "ERROR: privileged permission XML is missing from the USB patch folder"
    exit 1
fi

echo "--- System state before copy ---"
ls -ld /system /system/priv-app /system/priv-app/EQDsp /system/etc/permissions
ls -l /system/priv-app/EQDsp/EQDSP.apk
cat /system/etc/permissions/privapp-permissions-com.eqdsp.controller.xml

echo "--- Remount /system read-write ---"
mount -o remount,rw /system
if [ $? -ne 0 ]; then
    echo "ERROR: /system remount failed"
    mount
    exit 1
fi
mount

mkdir -p /system/priv-app/EQDsp
if [ $? -ne 0 ]; then
    echo "ERROR: unable to create /system/priv-app/EQDsp"
    exit 1
fi

mkdir -p /system/etc/permissions
if [ $? -ne 0 ]; then
    echo "ERROR: unable to create /system/etc/permissions"
    exit 1
fi

echo "--- Copy APK and permission XML ---"
cp -f /storage/sdcard1/eqdsp-privileged/EQDSP.apk /system/priv-app/EQDsp/EQDSP.apk
if [ $? -ne 0 ]; then
    echo "ERROR: APK copy failed"
    exit 1
fi

cp -f /storage/sdcard1/eqdsp-privileged/privapp-permissions-com.eqdsp.controller.xml /system/etc/permissions/privapp-permissions-com.eqdsp.controller.xml
if [ $? -ne 0 ]; then
    echo "ERROR: permission XML copy failed"
    exit 1
fi

chown 0.0 /system/priv-app/EQDsp
chmod 0755 /system/priv-app/EQDsp
chown 0.0 /system/priv-app/EQDsp/EQDSP.apk
chmod 0644 /system/priv-app/EQDsp/EQDSP.apk
chown 0.0 /system/etc/permissions/privapp-permissions-com.eqdsp.controller.xml
chmod 0644 /system/etc/permissions/privapp-permissions-com.eqdsp.controller.xml

echo "--- System state after copy ---"
ls -ld /system /system/priv-app/EQDsp /system/etc/permissions
ls -l /system/priv-app/EQDsp/EQDSP.apk
ls -l /system/etc/permissions/privapp-permissions-com.eqdsp.controller.xml
md5sum /storage/sdcard1/eqdsp-privileged/EQDSP.apk /system/priv-app/EQDsp/EQDSP.apk
md5sum /storage/sdcard1/eqdsp-privileged/privapp-permissions-com.eqdsp.controller.xml /system/etc/permissions/privapp-permissions-com.eqdsp.controller.xml
cat /system/etc/permissions/privapp-permissions-com.eqdsp.controller.xml

echo "--- SELinux relabel ---"
/system/bin/restorecon -RF /system/priv-app/EQDsp
/system/bin/restorecon /system/etc/permissions/privapp-permissions-com.eqdsp.controller.xml

sync
echo "SUCCESS: files copied and synchronised. The head unit will now reboot."
