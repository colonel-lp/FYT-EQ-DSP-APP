#!/system/bin/sh
/system/bin/sh /storage/sdcard1/eqdsp-loudness/run.sh install
