# Joying DSP processing r2 — service patch and USB installer 2.1

For the owner's SC9853i / sp9853i_1h10 reference firmware: Android 8.1/API 27, customer 43, C32107 driver 6 and the exact `com.syu.ms` APK below. This extends the working Loudness r1 service with independent TA/rear Surround routing, crossover shapes, sub polarity and one subwoofer PEQ. Matching model names or APK names alone do not establish compatibility.

The service APK is rebuilt and signed with its original matching identity. Its original manifest, resources, assets and native libraries are retained; 13 vendor method bodies are retained behind wrappers, with the Sound registration/dispatch hooks and new helpers. The decompiled Java application is not recompiled. See [DSP behavior](https://github.com/colonel-lp/Joying-EQ-DSP/blob/main/docs/functionality/DSP-PROCESSING.md) and [validation](https://github.com/colonel-lp/Joying-EQ-DSP/blob/main/docs/00-BUILD-VALIDATION.md).

The main EQ & DSP controller remains source-only; the current diagnostic controller is **1.63-beta / code 84**. Build/install that controller source with your existing app signing key to use the new controls. This ZIP contains the patched system service, not a controller APK. Existing Loudness protocol/settings remain supported. r2 passed local binary/installer checks and the owner has installed it with a verified r2 target hash. Loudness reports Registers verified, but Processing remains unavailable; its runtime cause is under investigation. Audio behavior is not confirmed.

## Use the ready-made package

Download `EQ-DSP-loudness-TA-crossover-sub-r2.zip`, or use the matching files in `tools/loudness-TA-crossover-sub-r2/`. Read `PATCH-MANIFEST.json` for the actual patched APK hash/size and certificate. Each procedure folder includes the same working reference `lsec6521update`; do not substitute an updater from another platform.

1. Keep the RESTORE files and correct firmware recovery procedure available. Use stable power, low master volume, Loudness OFF and cutoff 0 for initial checks.
2. On a clean FAT32 USB drive, copy the **contents of USB-CHECK** to the USB root, including `lsec6521update`, `lsec_updatesh` and `eqdsp-loudness`. Do not copy the outer folder or combine it with another updater/firmware package.
3. Run the same established FYT USB update procedure as the working Loudness patch. Follow its normal USB-removal/reboot process. Require **CHECK PASSED** and **RESULT: SUCCESS** in `eqdsp-processing-r2-check.log`. CHECK only writes its USB log; it does not replace APKs, move optimized files, remount partitions or clear service data.
4. After CHECK succeeds, replace the procedure files with the **contents of USB-INSTALL**, retaining the USB backup folder if present. Run the same updater process. Require **RESULT: SUCCESS** in `eqdsp-processing-r2-install.log` before rebooting normally. Do not bypass a refusal or edit a hash.
5. In the controller, wait for connection and confirmed r2 capabilities/readback. Check TA with CLEAN/SURROUND OFF first, then independent Surround, filter shapes and sub processing at low volume. Confirm left-only/right-only rear playback, delays, physical sub output, registers, presets/Undo/A-B/bypass, source changes and sleep/full restart. Register verification is not an acoustic measurement.

Only one CHECK, INSTALL or RESTORE launcher belongs on the USB at a time. Downloads do not run the updater.

## Restore and upgrade behavior

Use the **contents of USB-RESTORE** and require `RESULT: SUCCESS` in `eqdsp-processing-r2-restore.log`. This restores the complete byte-identical **factory service**, removing both the Loudness and processing extensions. The controller falls back to supported stock controls. It is not a return to the r1 extension.

INSTALL accepts the exact factory APK, the known installed r1 APK, or this package's r2 APK. App/service data and saved Loudness settings are retained. Active processing settings persist in the service's private `eqdsp-processing-v1.properties`; the factory service ignores this file. Reinstalling r2 can reuse saved extension settings.

On first r2 setup, CLEAN removes rear crossfeed independently of TA. Crossover shapes start at JOYING, sub EQ OFF and polarity JOYING. This changes the factory rear routing when TA is enabled; confirm it on the reference unit.

The USB backup remains `eqdsp-loudness-backup-r1` for compatibility. Factory and r1 optimized-file backups use different suffixes. A replacement failure attempts to restore the **pre-operation** APK and optimized files, including r1 during an upgrade. The deliberate RESTORE action always installs the supplied factory APK. Keep the USB backup/logs.

## Exact identities and guards

- Factory APK SHA-256: `faa39d4be2cf0d040c2a9ca3cd5d4e3aa3d4b5e2e1573b14168d676f8b031c97`.
- Previous r1 APK SHA-256: `ed56d85d99d4cf4ef3df1314a1e6a4f1846d6dbb5728a954b90ec1923bdfd419`.
- Matching service signer SHA-256: `c8a2e9bccf597c2fb6dc66bee293fc13f2fc47ec77bc6b2b0d52c11f51192ab8`; v1 and v2 signatures. This is the matching public AOSP platform test identity, separate from the controller's key. No key is distributed.
- Included reference updater SHA-256: `04b1509cb9b06048c57c86798953a7e4d9f2785ba11de1e01804e99ec7da59f0` (1,742,716 bytes).
- Original service: `com.syu.ms`, version 1.0 / 2004080958, shared UID `android.uid.system`. Version/package identity is retained.

The installer requires root, the reference device/API/customer, verified payload hashes, one regular `190000000_com.syu.ms.apk` under `/oem/app`, `/system/app` or `/system/priv-app` (directly or one subfolder deep), an offline Android framework and a matching registered package path when packages.xml is available. It refuses unknown service bytes, symlinks, duplicate targets, `/data/app` service updates and unknown staging residue. Customer-property CRLF is accepted; script files use LF.

The installer stages/renames on the target filesystem, checks committed hashes and normalizes root:root 0644/SELinux labels. Only adjacent same-basename odex/vdex/oat files under the APK directory or its arm/arm64/x86/x86_64 oat folders move aside. Android regenerates those after a successful install/restore. No broad cache wipe, uninstall, data clearing or partition flash is performed.

## Rebuild the service patch

Use JDK 17, Android SDK platform 35/build-tools 35.0.0 and apktool 2.12.1. Start with the exact factory APK, not an installed r1/r2 APK. Supply the original matching key/certificate locally; never generate a replacement identity.

```sh
python3 tools/loudness-service/build.py --original /path/original.apk --apktool /path/apktool.jar --sdk /path/android-sdk --key /private/platform.pk8 --cert /private/platform.x509.pem --output /path/service-r2.apk
# Install androguard 4.1.4 for this structural/linkage check:
python3 tools/loudness-service/verify_apks.py /path/original.apk /path/service-r2.apk
python3 tools/loudness-service/package.py --original /path/original.apk --patched /path/service-r2.apk --apksigner /path/android-sdk/build-tools/35.0.0/apksigner --output /path/EQ-DSP-loudness-TA-crossover-sub-r2.zip
```

Compile-only vendor stubs are not copied into the service. The build retains the original service smali, adds only the extension/shared-model classes and required compiler-generated helpers, then aligns/signs/verifies it. `verify_apks.py` checks retained vendor bodies, original resources and actual DEX member linkage. `package.py` verifies the matching signature and updater, inserts the real APK hash into all three LF scripts, and checks the ZIP's payloads/launchers.

The canonical `tools/loudness-service/run.sh` contains `PATCHED_SHA256` and is build input. Only the generated script in `tools/loudness-TA-crossover-sub-r2/USB-*/eqdsp-loudness/run.sh` is a finished installer.

## Protocol and local checks

Existing Loudness protocol 1 remains on commands `0x455100`–`0x455103`, callbacks 120–123. Processing protocol 1 uses commands `0x455110`–`0x455112`, callbacks 124–127 and magic `0x45515032`. Capabilities, customer/driver/readiness, caller UID, revision and bounded values gate new operations. See [protocol/behavior details](https://github.com/colonel-lp/Joying-EQ-DSP/blob/main/docs/functionality/DSP-PROCESSING.md).

Focused source checks: `python3 tools/tests/processing/run.py` and `python3 tools/tests/loudness/test_installer.py`. Simulated I2C/installer stand-ins, DEX checks and valid signatures do not prove physical audio behavior, restart persistence or inaudible transitions. The earlier owner verification applies to r1; r2 requires its own unit checks.


## Script/log identity maintenance

Installer 2.1 changes the banner/log filenames and adds expected/verified hash reporting. The service APK, its signing identity and payload hashes remain unchanged. The r1 backup/staging identifiers are retained for upgrade/rollback compatibility. CHECK, INSTALL and RESTORE now write `eqdsp-processing-r2-check.log`, `eqdsp-processing-r2-install.log` and `eqdsp-processing-r2-restore.log` respectively.

The existing public archive is `EQ-DSP-loudness-TA-crossover-sub-r2.zip`. Its scripts may predate this source-only maintenance and retain their bundled older log names. The committed procedure folders contain the reference updater; the current source `package.py` recipe intentionally omits the updater, so add that exact compatible trigger separately when using a newly generated ZIP.
