# Loudness r1 / installer 1.1 — complete reference USB procedures

Canonical folder: `tools/loudness-r1.1/`. Scripts formerly split into the differently capitalised `tools/Loudness-r1.1` have been merged here with the matching APK payloads and updater. The r1 APK is unchanged. Current source logs are `eqdsp-loudness-r1.1-check.log`, `eqdsp-loudness-r1.1-install.log` and `eqdsp-loudness-r1.1-restore.log` at USB root. Each USB procedure includes the exact reference updater; copy one procedure's contents only.

The source/build notes below describe the historical r1 implementation. The current `tools/loudness-service` generator produces **r2**, so do not use its current HEAD to reproduce the archived r1 APK. Use the supplied hash-verified r1 procedures or the appropriate historical source revision.

# Joying Loudness extension r1 — installer 1.1; EQ & DSP v1.57-beta / build 78

For the owner's SC9853i / sp9853i_1h10, Android 8.1/API 27, configured customer 43. Built from the supplied `190000000_com.syu.ms.apk`; original package com.syu.ms 1.0 / 2004080958, shared UID android.uid.system. This tool changes only C32107 and Sound command/registration hooks plus six helper classes. All original vendor methods, fields, manifest, resources, assets and native libraries are retained. No hardware installation/test is claimed.

Original SHA-256: `faa39d4be2cf0d040c2a9ca3cd5d4e3aa3d4b5e2e1573b14168d676f8b031c97`.

Signer SHA-256: `c8a2e9bccf597c2fb6dc66bee293fc13f2fc47ec77bc6b2b0d52c11f51192ab8`. The service patch is signed with the matching public AOSP platform test certificate, v1 and v2. Keys are not included or committed. Keep the app's existing, separate signing key for update compatibility.

## Use the USB package

This is the corrected installer revision 1.1, replacing the initially delivered script. The service/app APKs are unchanged. First copy the **contents of USB-CHECK**, including its reference `lsec6521update`, to the USB root. Run the usual updater process and read `eqdsp-loudness-r1.1-check.log`: require `CHECK PASSED` and `RESULT: SUCCESS`. This checks the actual launcher, command availability, captured device/profile, payload hashes, target and package path without changing an APK, optimized file, mount or service data; only its USB log is written. After success, replace the entry-point/payload files with the **contents of USB-INSTALL** and run the updater again. Do not mix entry points from the three folders.

1. Start at a low master volume, Loudness OFF and app cutoff 0. Keep the restore folder available.
2. Copy the **contents** of USB-INSTALL to the FAT32 USB root. Add the same `lsec6521update` binary from your working USB method beside `lsec_updatesh`. The complete canonical procedure includes the exact reference updater; do not substitute one from another platform. Do not copy the outer USB-INSTALL folder or mix these files with another update package.
3. Use the existing lsec update process. Its small wrapper runs the real `/system/bin/sh` script. Let the updater finish and follow the normal USB-removal/reboot process.
4. Check `eqdsp-loudness-r1.1-install.log` for `RESULT: SUCCESS`. A refusal explains which preflight failed; do not change hashes to bypass it. The script supports only the exact service basename under /oem/app, /system/app or /system/priv-app, directly or one subfolder deep. It requires a unique regular target, exact original/patch bytes, root execution, customer 43, the expected device/API, an offline framework and matching package registration when packages.xml is available. It rejects service updates under /data/app. Staged/rollback APKs are set to root:root 0644 and relabelled before use.
5. Build/sign the v1.57-beta app with your existing app key, install it, wait for CONNECTED and long press LOUDNESS. Confirm STOCK and the readback status first. Then select CUSTOM, small depth/corner changes and SAVE. Settings entered while OFF are staged and apply on the next ON.

To undo the service patch, copy the **contents** of USB-RESTORE to the USB root, retaining the same working updater binary, run lsec and check the restore log before reboot. It restores the complete byte-identical original APK. It preserves app/service data and all unrelated files. The service's separate custom preference remains ignored by the original APK; SAVE STOCK first if you do not want custom settings restored on a later reinstall. App cutoff remains an independent app preference.

The installer backs up the full original APK plus target path/metadata on USB, stages/renames on the target filesystem and verifies committed bytes. On failure after replacement it attempts the pre-operation APK and optimized-file rollback. Only adjacent same-basename odex/vdex/oat files under the APK directory or its arm/arm64/x86/x86_64 oat folders are moved aside and hash recorded. Successful restore leaves those original/patch optimized backups aside so Android can regenerate from the restored APK. No broad Dalvik-cache wipe, APK uninstall, data clearing, partition flash or service restart during live Android is performed. Staging residue or a collision with an optimized backup causes refusal, not deletion of unknown files.

## Limited-command compatibility

The outer `lsec.sh` is exactly the shebang `#!/system/bin/sh` and one `/system/bin/sh /storage/sdcard1/eqdsp-loudness/run.sh <mode>` command. It contains no variable assignments, functions, traps or multiline conditionals. This matches the retained earlier installed Visualizer/extractor launcher format; all stateful logic is inside the complete child shell process.

Installer 1.1 removes `stat`, `sed`, `cp -p`, and `chown 0:0`; it uses plain `cp` and the previously used `chown 0.0`. Properties and package paths are read with POSIX shell built-ins, including handling the supplied fyt.prop's CRLF endings. It uses no awk, pm, am or explicit reboot. Its external commands are sha256sum, pidof, getprop, id, cat, cp, mv, chown, chmod, mkdir, rm, ls, mount, sync and the existing absolute restorecon path, matching the retained earlier script's command set. All are checked before staging. Input hashes, unique target, customer/device and package-path guards remain active. APK permissions are explicitly normalized instead of depending on an unavailable stat option or metadata-preserving cp option.

The corrected script passes 135 checks with a restricted PATH, rejected unsupported tools/options and a line-by-line outer-launcher simulation, including the real captured CRLF property file, package-record variations/refusal, install/restore/idempotence and rollback. These are local checks with command stand-ins; the USB-CHECK run verifies the actual unit environment before installation. An ordinary shell supports variables, but the lsec line processor does not preserve assignments between entry-point lines.

## Build locally

Use JDK 17, Android SDK platform 35/build-tools 35.0.0 and apktool 2.12.1. Supply original APK and the matching AOSP platform test key/cert locally:

```sh
python3 tools/loudness-service/build.py --original /path/original.apk --apktool /path/apktool.jar --sdk /path/android-sdk --key /private/platform.pk8 --cert /private/platform.x509.pem --output /path/service-r1.apk
```

The build refuses a different original hash. Compile-only thin vendor stubs are never copied into the final service; only EqDspLoudness helper smali is added. The original Java decompile is not rebuilt. Signature and alignment checks run before success.

For the app, open `source/` in Android Studio and generate a signed APK with the existing key. The supplied unsigned APK can also be signed with that key using Android `apksigner`; it cannot be installed until signed. `build_app.py --sdk /path/android-sdk --output /path/unsigned.apk` reproduces the SDK resource/Java/DEX compilation used for validation. No different app signing key is substituted.

## Protocol

Existing Sound transport only. Integer arrays; no float/string payloads. Magic `0x45514453`, version 1; positive request token. Requests capture Binder UID before posting. Mutations allow system UID 1000 or the UID containing com.eqdsp.controller. Caller/driver/customer/readiness/revision validation precedes custom writes; read/probe remain available to clients.

| Command | Integer request |
| --- | --- |
| PROBE 0x455100 | magic, version, token |
| APPLY 0x455101 | magic, version, token, expectedRevision, persist0or1, mode0or1, low0to6, high0to6, hiBoost0to3, 37 curve entries |
| MODE 0x455102 | magic, version, token, expectedRevision, persist0or1, mode0or1 |
| READ 0x455103 | magic, version, token, verifyHardware0or1 |

Every callback begins `[magic,version,serviceInstance,token,revision]`; token 0 is an unsolicited/native state update. Registering CAPS/CONFIG/STATE with flush returns cached current state. READ with verify=1 reads the chip and returns state/outcome.

| Callback | Remaining fields |
| --- | --- |
| CAPS 120 | patchRevision, featureMask, liveCustomer, driverType, ready, baselineR |
| CONFIG 121 | mode, low, high, hiBoost, savedRevision, 37 curve entries |
| STATE 122 | commandedOn, effectiveVolume, currentR, status, verified, setup0002, corner0701, gain0702, boost0906..090A, failedRegister |
| RESULT 123 | capturedCallerUid, command, status, verified, persisted |

Status codes: 0 queued, 1 bad argument, 2 stale revision, 3 unauthorized, 4 profile/driver mismatch, 5 not ready, 6 staged while OFF, 7 write failed, 8 read failed, 9 mismatch, 10 unverified, 11 verified, 12 save failed, 13 superseded device. Configuration/persistence acknowledgement and physical verification are distinct. READ errors keep verified=false; signed Java byte values are decoded as unsigned except the native -1 sentinel. The app coalesces parameter previews and times out unanswered mutations after four seconds.

Curve entries are half-dB compensation codes 0..30; index 0 must be 0. For the current driver index v, depth is -floor(curve[v]/2) dB and extra compensation is curve[v]/2.0 dB. Fixed depth d uses entries 1..36=2d. The current R is added to compensation and must produce 0..72. Filter 0701=(high<<4)|low; gain 0702=0x80|(HiBoost<<4)|floor(curve[v]/2); five boost registers=128-(R+curve[v]). The existing SR/mix 090B is untouched. Level command 52 retains its separate normal attenuation-table meaning.

## Validation and first device checks

```sh
python3 tools/tests/loudness/run.py
python3 tools/tests/loudness/test_installer.py
sh tools/tests/bypass/run.sh
sh tools/tests/preset/run.sh
# Install androguard 4.1.4 for structural verification:
python3 tools/loudness-service/verify_apks.py original.apk service-r1.apk --app unsigned.apk
```

After first boot, check service startup, STOCK behavior and registers with cutoff 0. Test fixed and adaptive modes at volume 0/1/24/25/36, OFF staging/SAVE/CANCEL/Undo, corners and HiBoost, hardware master-volume controls, Level, mute, source changes, bypass/live includes, A/B and sleep/wake/full DSP reinitialization. Compare staged/applied/saved/verified status with the behavior you hear. Conservative register sequencing and local tests do not establish click-free sound or signal headroom. The Post-EQ Loudness graph remains approximate and the Line In Visualizer investigation remains open.

