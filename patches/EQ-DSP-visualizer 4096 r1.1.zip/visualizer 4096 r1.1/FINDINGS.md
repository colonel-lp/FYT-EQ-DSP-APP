# EQ & DSP — audio/DSP investigation catalogue

23 September 2026 · Source: supplied `eqdsp-visualizer-extract-v2.zip` and
existing EQ & DSP v1.15 source. Static inspection only; no device commands run.

## Main outcomes

1. A firmware-specific 4096-waveform patch is built with stock restore files.
2. The HAL contains real playback-dump code, not just configuration labels.
   This is a promising future continuous-capture lead, but is not yet a working
   capture method and is deliberately not enabled.
3. The archive contains no `com.syu.ms` APK. New Joying DSP commands cannot be
   established from it. A targeted read-only extractor is included.
4. No confirmed sound-quality improvement, new DSP control, or post-DSP capture
   has been demonstrated by this static investigation.

## Confirmed extracted-file findings

| ID | Finding and evidence | What it means |
| --- | --- | --- |
| A01 | `system-bin-audioserver` is ELF32 x86; system properties list x86_64/x86 | Both client ABIs matter; the actual audio server uses the 32-bit effect library. |
| A02 | `system-etc-audio_effects.conf` points Visualizer to `/vendor/lib/soundfx/libvisualizer.so` | This is the effect being targeted, not an assumed generic system path. |
| A03 | Both vendor Visualizer libraries contain a 65536-byte capture ring, a 1024 default, and a set-size rejection above 1024 | Longer snapshots can fit without enlarging the ring. This is necessary, not sufficient, evidence of runtime compatibility. |
| A04 | `libmedia.so` client set-size checks allow powers of two in 128–1024 | Patching only the vendor effect would still leave clients rejecting 4096. |
| A05 | Both client `periodicCapture` implementations allocate waveform buffers from current capture size | No fixed 1024-byte callback stack buffer was found in these inspected methods. |
| A06 | JNI `getCaptureSizeRange` still reports 128–1024 | Left unchanged deliberately; other apps are not encouraged to request oversized packed FFTs. |
| A07 | Both client libraries call external `fixed_fft_real` | Larger native FFTs are not assumed safe. The external implementation itself was not in the archive. The patch guards `doFft` above 1024 and returns zeroed FFT output; callbacks/getFft wrappers may discard its error code. |
| A08 | Primary policy lists PCM16 stereo 44100 for the normal output; remote-submix lists PCM16 stereo 48000 | Raising sample rate is not a bass-resolution fix. The patch changes capture duration, not the output rate. |
| A09 | `audio_hw.xml` declares dump targets including `dump_primary_vbc.pcm` and `dump_offload_vbc.pcm`; dump switches are zero | Factory diagnostic capture points exist in configuration, but availability and actual data require testing. |
| A10 | Primary HAL has `do_dump` at VA `0x19b40`, `dump_to_buffer` at `0x19750`, `dump_to_file` at `0x198c0` | There is executable dump code. A future analyser tap may be possible; filenames alone do not prove safe live capture. |
| A11 | Embedded mini-debug symbols identify `out_write` at `0x2b1d0`; calls to `do_dump` occur inside it at `0x2cc1b`, `0x2d3cc`, `0x2da36`, `0x2e0b7` | Dump hooks are connected to output processing. Their exact stage, format, scheduling cost, and source coverage still need tracing. |
| A12 | `ext_get_dump_data_switch` at `0x24250` reads property string `media.dump.switch` (VA `0x4ce6c`) then calls `set_dump_switch` | Concrete control lead; do NOT treat the bitmask or safe usage as decoded. No property has been changed. |
| A13 | HAL references `/vendor/etc/tiny_hw.xml`, `/vendor/etc/codec_pga.xml`, `libvbeffect.so`, `libvbpga.so`, `libdumpdata.so` | These missing dependencies/configs are useful next inputs for routing, gain-stage and dump analysis. |
| A14 | `audio_hw.xml` contains IIS switches such as `SYS_IIS3` to `ap_iis1`/`tgdsp_iis1` | An I²S route exists in the vendor design. This is not proof that any exposed capture endpoint mirrors speaker output. |
| A15 | The same generic config mentions `Tfa9897` and disabled smart-amp management | Not reliable identification of the physical amplifier/DSP. Do not report this as the unit's actual chip. |
| A16 | Effects config declares generic bassboost/equalizer/loudness-enhancer libraries | Declared effects are not proof they are active. They are separate from Joying's service-controlled DSP; no extra effects have been enabled. |

Addresses above are ELF virtual addresses, not necessarily file offsets.
`PATCH-MANIFEST.json` records both for every patch location. Original binaries
and build IDs are not independent runtime proof; patched files retain build IDs
but have new SHA-256 hashes.

## Native patch design

| Target | Change |
| --- | --- |
| `/system/lib/libmedia.so` | Allow 128–4096 powers of two; guard oversized native FFT calls |
| `/system/lib64/libmedia.so` | Same change for x86_64 clients |
| `/vendor/lib/soundfx/libvisualizer.so` | Accept waveform size up to 4096; adjust rejection log bound |
| `/vendor/lib64/soundfx/libvisualizer.so` | Same effect change for x86_64 |

The default capture size, advertised JNI range, ring size, sample rate, scaling,
audio policy, primary HAL, DSP service and audio-effect chain remain unchanged.
There are 103 changed bytes across four exact-input files. Safety guards use
verified existing executable NOP padding and replay complete overwritten
prologue instructions before normal <=1024 transforms. Symbol entry addresses,
ELF layout and CFI tables remain unchanged; real Android runtime testing is
still required.

Why this differs from the initial six-library idea: increasing the advertised
JNI maximum could make other apps choose 4096 for Android's packed FFT. The
safer design leaves that range alone, makes EQ & DSP opt in explicitly, and
also suppresses oversized native FFT calls in case another client encounters
the enlarged effect. It does not add support for a 4096-point native packed FFT.

The standard Android fixed-point FFT source uses a 1024-size table limit. This
informed the conservative guard; the exact firmware's external FFT library
still needs collection rather than assuming it is identical:
[AOSP fixedfft.cpp](https://android.googlesource.com/platform/system/media/+/android-7.0.0_r1/audio_utils/fixedfft.cpp).

## App companion

`EQ-DSP-v1.16-beta` (build 37) adds checked 4096 waveform negotiation on this
platform and retains fallback on stock firmware. Its independent Java analyser
uses 4096 samples below 600 Hz, the newest 1024 above 1000 Hz, and a smooth
crossfade in between. All 2048 positive-frequency bins are retained.

At 44100 Hz the bass bin spacing is 10.77 Hz and window is 92.88 ms, versus
43.07 Hz / 23.22 ms at 1024. This is not a 4x increase in sample rate or a claim
of 10.77 Hz resolving power for all windowed signals. The Hann window spreads
tones over several bins; the lowest bass remains the hardest region.

Visualizer remains an Android mono, 8-bit snapshot; this investigation does not
establish a measured external-DSP output tap. Automatic normalisation and existing
visual scaling mean the vertical display is not a calibrated sound-level or
clipping meter. Post-EQ is a model, not measurement.
No audio routing or real EQ/P²Bass settings change in this build.

## Existing app command map — baseline, not new discoveries

From `MainActivity.java`, sound module 4 via action `com.syu.ms.toolkit`, package
`com.syu.ms`; descriptors `com.syu.ipc.IRemoteToolkit`, `IRemoteModule`, and
`IModuleCallback`. Toolkit get-module transaction 1; module command 1,
register 3, unregister 4; callback update 1.

| Function | Write command | Update code(s) |
| --- | ---: | --- |
| Master volume / mute protocol | 0 | 2 / 3 |
| EQ gain | 1 | 9 |
| Joying EQ mode | 2 | 10 |
| Balance/fade | 3 | 8 |
| Loudness | 5 | 11 |
| Amp | 7 | 13 |
| EQ frequency | 15 | 18 |
| EQ Q | 16 | 20 |
| Sub gain | 23 | 26 |
| Sub filters | 25 | 27 |
| P²Bass master | 26 | 28 |
| P²Bass gain | 27 | 29 |
| P²Bass frequency | 28 | 30 |
| Front/rear HPF | 29 | 31 |
| Surround | 30 | 32 |
| Time-alignment mode | 31 | 33 |
| Time-alignment distances | 32 | 34 |
| Surround IIR A/B | 33 | 35 |
| EQ independent/linked mode | 35 | 37 |
| Sub on/off | 36 | 38 |
| Output level | 52 | 51 range / 52 value |
| Joying analyser | No new write established | 0 |

App selectors: front `0x10000`, rear `0x20000`; TA FL/FR/RL/RR
`0x11000/0x12000/0x21000/0x22000`; IIR A/B `16/32`; sub LPF/HPF `0/256`.
The app defaults output range to 0–60 and listens for update 51. Do not hardcode
the older 0–50 assumption in future tools. This catalogue does not establish
new valid arguments or authorise blind command sweeps.

## Ranked next investigations

1. **Joying service APK and factory EQ client.** Decode service dispatch,
   argument bounds, readbacks, MCU transport, and chip-specific branches. Most
   useful for command 52/headroom, precise filter mappings and time alignment.
   Toolkit is an action implemented by the service; a separate toolkit APK is
   not assumed. The current archive contains no service APK.
2. **Bounded playback tap.** Trace `media.dump.switch`, `set_dump_switch`,
   `libdumpdata.so`, and output dump points. Establish the exact format and a
   reliable stop mechanism before any test. Continuous raw file dumps would
   create storage wear, privacy and performance problems; they are not a
   production analyser design. A bounded RAM tap would need further work.
3. **Gain staging.** Map codec PGA/VBC gains versus the external Joying DSP's
   output-level control. A headroom warning based on modelled boost could be
   useful, but lowering a downstream level does NOT necessarily prevent
   upstream DSP clipping. Establish where attenuation happens before offering
   automatic compensation as a sound-quality feature.
4. **TA without surround coloration.** Trace IIR A/B and rear-channel mirroring
   in the service. Existing results do not prove a fully neutral mode or
   independent RL2/RR2. No new claim is made here.
5. **Source coverage and post-DSP.** Investigate FM/AUX/Bluetooth separately.
   Generic ALSA capture endpoints and I²S labels do not establish a usable
   post-DSP feedback path. Keep Visualizer as the normal non-routing fallback.

No changes to sample-rate policy, mixer gains, hardware test-loop controls,
generic effects, SELinux, verified boot, or DSP firmware are part of this patch.

## Recorded limitations and pending work

- Unit tests and simulations do not validate Android boot, shared-effect
  interactions, vendor timing or sustained audio on the head unit.
- Factory normalization over successive processing blocks can still limit
  measurement accuracy even with a longer waveform window.
- Other apps still see a 1024 advertised maximum. If they use the same enlarged
  effect without resetting its size and request packed FFT, they may show zero
  FFT data; this is preferable to calling an unverified oversized transform.
- UI request to reveal/select front/rear EQ when its colour editor is opened
  remains catalogued for a UI build; it is not part of this capture-only change.
- No actual DSP chip identification is newly established. BU32107 remains the
  project's tested-unit reference, not a fresh runtime detection.

## Evidence preservation

Patch inputs are reproduced as stock restore payloads, with exact hashes in the
manifest. Scripts and tests are included. Original extracted configuration and
HAL files remain untouched. The optional extractor reads only selected APKs
and factory dependencies, does not export the complete package database, and
does not capture audio, personal identifiers or user app settings.
