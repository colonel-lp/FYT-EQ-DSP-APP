#!/system/bin/sh
# Installer 1.1. The lsec entry point launches this entire file with /system/bin/sh.
EQDSP_MODE=$1
EQDSP_USB=/storage/sdcard1
EQDSP_PAYLOAD=$EQDSP_USB/eqdsp-loudness
EQDSP_BACKUP=$EQDSP_USB/eqdsp-loudness-backup-r1
EQDSP_ORIGINAL=faa39d4be2cf0d040c2a9ca3cd5d4e3aa3d4b5e2e1573b14168d676f8b031c97
EQDSP_PATCHED=ed56d85d99d4cf4ef3df1314a1e6a4f1846d6dbb5728a954b90ec1923bdfd419
EQDSP_TARGET=
EQDSP_CHANGED=0
EQDSP_MOVED=0
EQDSP_STAGE_OWNED=0
EQDSP_PREV_OWNED=0
EQDSP_COMP_SUFFIX=stock
EQDSP_NEW_COMPANIONS=$EQDSP_BACKUP/moved-$EQDSP_MODE.txt
EQDSP_RESULT=FAILED
fail() { echo "ERROR: $*"; exit 1; }
hash_file() { EQDSP_LINE=$(sha256sum "$1") || return 1; echo "${EQDSP_LINE%% *}"; }
check_hash() { [ -f "$1" ] && [ ! -L "$1" ] && [ "$(hash_file "$1")" = "$2" ]; }
apk_permissions() {
    chown 0.0 "$1" || return 1
    chmod 0644 "$1" || return 1
    /system/bin/restorecon "$1" || return 1
}
companions() {
    EQDSP_DIR=${EQDSP_TARGET%/*}
    EQDSP_NAME=${EQDSP_TARGET##*/}
    EQDSP_STEM=${EQDSP_NAME%.apk}
    for EQDSP_ARCH in . oat/arm oat/arm64 oat/x86 oat/x86_64; do
        for EQDSP_EXT in odex vdex oat; do
            "$1" "$EQDSP_DIR/$EQDSP_ARCH/$EQDSP_STEM.$EQDSP_EXT" || return 1
        done
    done
}
check_companion() {
    [ ! -L "$1" ] && [ ! -L "$1.eqdsp-loudness-r1-$EQDSP_COMP_SUFFIX" ] || return 1
    if [ -e "$1.eqdsp-loudness-r1-$EQDSP_COMP_SUFFIX" ]; then
        [ ! -e "$1" ] || return 1
        [ -f "$1.eqdsp-loudness-r1-$EQDSP_COMP_SUFFIX.sha256" ] || return 1
        check_hash "$1.eqdsp-loudness-r1-$EQDSP_COMP_SUFFIX" "$(cat "$1.eqdsp-loudness-r1-$EQDSP_COMP_SUFFIX.sha256")" || return 1
    fi
    [ ! -e "$1" ] || [ -f "$1" ]
}
move_companion() {
    [ -e "$1" ] || return 0
    if [ -e "$1.eqdsp-loudness-r1-$EQDSP_COMP_SUFFIX" ]; then
        # Refuse a second optimized file; do not discard an unknown newer artifact.
        echo "Both live and backed-up optimized file exist: $1"; return 1
    fi
    hash_file "$1" >"$1.eqdsp-loudness-r1-$EQDSP_COMP_SUFFIX.sha256" || return 1
    echo "$1" >>"$EQDSP_NEW_COMPANIONS" || return 1
    mv "$1" "$1.eqdsp-loudness-r1-$EQDSP_COMP_SUFFIX" || return 1
}
restore_companion() {
    [ -e "$1.eqdsp-loudness-r1-$EQDSP_COMP_SUFFIX" ] || return 0
    [ ! -e "$1" ] || { echo "Optimized target exists: $1"; return 1; }
    check_hash "$1.eqdsp-loudness-r1-$EQDSP_COMP_SUFFIX" "$(cat "$1.eqdsp-loudness-r1-$EQDSP_COMP_SUFFIX.sha256")" || return 1
    mv "$1.eqdsp-loudness-r1-$EQDSP_COMP_SUFFIX" "$1" || return 1
    /system/bin/restorecon "$1" || return 1
    rm "$1.eqdsp-loudness-r1-$EQDSP_COMP_SUFFIX.sha256" || return 1
}
finish() {
    EQDSP_EXIT=$?
    trap - 0 1 2 15
    if [ "$EQDSP_EXIT" != 0 ] && [ "$EQDSP_CHANGED" = 1 ]; then
        echo "Restoring the pre-operation APK."
        if check_hash "$EQDSP_TARGET.eqdsp-loudness-r1-prev" "$EQDSP_BEFORE"; then
            mv -f "$EQDSP_TARGET.eqdsp-loudness-r1-prev" "$EQDSP_TARGET"
            apk_permissions "$EQDSP_TARGET" || echo "CRITICAL: APK rollback permissions failed."
            check_hash "$EQDSP_TARGET" "$EQDSP_BEFORE" || echo "CRITICAL: APK rollback failed. Use USB-RESTORE."
        else echo "CRITICAL: pre-operation backup unavailable. Use USB-RESTORE."; fi
        if [ "$EQDSP_MOVED" = 1 ]; then
            while IFS= read -r EQDSP_COMP; do restore_companion "$EQDSP_COMP" || echo "Optimized-file rollback incomplete: $EQDSP_COMP"; done <"$EQDSP_NEW_COMPANIONS"
        fi
    fi
    if [ -n "$EQDSP_TARGET" ]; then
        if [ "$EQDSP_STAGE_OWNED" = 1 ] && [ -f "$EQDSP_TARGET.eqdsp-loudness-r1-stage" ]; then rm "$EQDSP_TARGET.eqdsp-loudness-r1-stage";fi
        if [ "$EQDSP_PREV_OWNED" = 1 ] && [ -f "$EQDSP_TARGET.eqdsp-loudness-r1-prev" ] && { [ "$EQDSP_EXIT" = 0 ] || check_hash "$EQDSP_TARGET" "$EQDSP_BEFORE"; }; then rm "$EQDSP_TARGET.eqdsp-loudness-r1-prev";fi
    fi
    sync
    echo "RESULT: $EQDSP_RESULT; exit $EQDSP_EXIT"
    exit "$EQDSP_EXIT"
}
case "$EQDSP_MODE" in install|restore|check) ;; *) exit 2;; esac
[ "$EQDSP_MODE" != restore ] || EQDSP_COMP_SUFFIX=custom
exec >"$EQDSP_USB/eqdsp-loudness-$EQDSP_MODE.log" 2>&1 || exit 1
trap finish 0
trap 'exit 130' 1 2 15
[ "$(id -u)" = 0 ] || fail "Root updater required."
echo "EQ & DSP Loudness installer 1.1: $EQDSP_MODE"
for EQDSP_CMD in sha256sum pidof getprop id cat cp mv chown chmod mkdir rm ls mount sync; do command -v "$EQDSP_CMD" >/dev/null 2>&1 || fail "Missing $EQDSP_CMD."; done
if pidof system_server audioserver >/dev/null 2>&1; then fail "Android is running. Use offline lsec updater."; fi
[ -x /system/bin/restorecon ] || fail "restorecon unavailable."
[ "$(getprop ro.product.device)" = sp9853i_1h10 ] || fail "Wrong unit."
[ "$(getprop ro.build.version.sdk)" = 27 ] || fail "Requires original Android 8.1 firmware."
EQDSP_CUSTOMER=$(getprop ro.build.fytmanufacturer)
if [ -z "$EQDSP_CUSTOMER" ]; then
    for EQDSP_PROP in /oem/fyt.prop /oem/app/fyt.prop; do
        [ -f "$EQDSP_PROP" ] || continue
        while IFS= read -r EQDSP_PROP_LINE || [ -n "$EQDSP_PROP_LINE" ]; do
            case "$EQDSP_PROP_LINE" in
                ro.build.fytmanufacturer=*)
                    EQDSP_PROP_VALUE=${EQDSP_PROP_LINE#ro.build.fytmanufacturer=}
                    echo "CUSTOMER: $EQDSP_PROP = <$EQDSP_PROP_VALUE>"
                    # Accept the captured fyt.prop's CRLF ending using shell pattern matching.
                    case "$EQDSP_PROP_VALUE" in
                        43|43"$(printf '\r')") EQDSP_PROP_VALUE=43;;
                        *) fail "Requires customer 43; conflicting/invalid property.";;
                    esac
                    [ -z "$EQDSP_CUSTOMER" ] || [ "$EQDSP_CUSTOMER" = "$EQDSP_PROP_VALUE" ] || fail "Conflicting customer properties."
                    EQDSP_CUSTOMER=$EQDSP_PROP_VALUE
                    ;;
            esac
        done <"$EQDSP_PROP"
    done
fi
[ "$EQDSP_CUSTOMER" = 43 ] || fail "Requires customer 43."
check_hash "$EQDSP_PAYLOAD/original.apk" "$EQDSP_ORIGINAL" || fail "Bad original payload."
check_hash "$EQDSP_PAYLOAD/patched.apk" "$EQDSP_PATCHED" || fail "Bad patch payload."
# Never replace an active /data/app update or guess a different APK basename.
for EQDSP_UPDATE in /data/app/com.syu.ms-* /data/app/*/com.syu.ms-*; do
    [ ! -e "$EQDSP_UPDATE" ] || fail "A data-app service update exists; inspect package path first."
done
for EQDSP_FILE in /oem/app/190000000_com.syu.ms.apk /oem/app/*/190000000_com.syu.ms.apk /system/app/190000000_com.syu.ms.apk /system/app/*/190000000_com.syu.ms.apk /system/priv-app/190000000_com.syu.ms.apk /system/priv-app/*/190000000_com.syu.ms.apk; do
    [ -e "$EQDSP_FILE" ] || continue
    [ -f "$EQDSP_FILE" ] && [ ! -L "$EQDSP_FILE" ] || fail "Unsafe APK target."
    [ -z "$EQDSP_TARGET" ] || fail "Multiple candidate service APKs."
    EQDSP_TARGET=$EQDSP_FILE
done
[ -n "$EQDSP_TARGET" ] || fail "Expected service APK path not found. No writes performed."
EQDSP_BEFORE=$(hash_file "$EQDSP_TARGET") || fail "Cannot hash target."
case "$EQDSP_BEFORE" in "$EQDSP_ORIGINAL"|"$EQDSP_PATCHED") ;; *) fail "Firmware mismatch: $EQDSP_TARGET ($EQDSP_BEFORE).";; esac
if [ -f /data/system/packages.xml ]; then
    EQDSP_CODEPATH=
    EQDSP_PACKAGE_FOUND=0
    while IFS= read -r EQDSP_PACKAGE_LINE || [ -n "$EQDSP_PACKAGE_LINE" ]; do
        case "$EQDSP_PACKAGE_LINE" in *'<package '*) ;; *) continue;; esac
        case "$EQDSP_PACKAGE_LINE" in *' name="com.syu.ms"'*) ;; *) continue;; esac
        [ "$EQDSP_PACKAGE_FOUND" = 0 ] || fail "Multiple service package records."
        EQDSP_PACKAGE_FOUND=1
        case "$EQDSP_PACKAGE_LINE" in *' codePath="'*) ;; *) fail "Missing registered package path.";; esac
        EQDSP_PATH_TAIL=${EQDSP_PACKAGE_LINE#*' codePath="'}
        EQDSP_CODEPATH=${EQDSP_PATH_TAIL%%'"'*}
        [ "$EQDSP_CODEPATH" != "$EQDSP_PATH_TAIL" ] || fail "Malformed registered package path."
    done </data/system/packages.xml
    [ "$EQDSP_CODEPATH" = "$EQDSP_TARGET" ] || [ "$EQDSP_CODEPATH" = "${EQDSP_TARGET%/*}" ] || fail "Registered package path does not match selected APK."
fi
for EQDSP_SUFFIX in stage prev; do [ ! -e "$EQDSP_TARGET.eqdsp-loudness-r1-$EQDSP_SUFFIX" ] && [ ! -L "$EQDSP_TARGET.eqdsp-loudness-r1-$EQDSP_SUFFIX" ] || fail "Staging residue exists; inspect it first."; done
EQDSP_FOLDER=patched.apk;EQDSP_WANTED=$EQDSP_PATCHED
if [ "$EQDSP_MODE" = restore ]; then EQDSP_FOLDER=original.apk;EQDSP_WANTED=$EQDSP_ORIGINAL;fi
if [ "$EQDSP_MODE" = check ]; then
    companions check_companion || fail "Optimized-file preflight failed."
    EQDSP_RESULT=SUCCESS
    echo "CHECK PASSED: launcher, required commands, unit/profile, payloads and target verified."
    echo "TARGET: $EQDSP_TARGET; SHA256: $EQDSP_BEFORE"
    echo "No APK, optimized file, mount or service-data changes performed."
    exit 0
fi
if [ "$EQDSP_BEFORE" = "$EQDSP_WANTED" ]; then EQDSP_RESULT=SUCCESS;echo "Already at requested APK; no system writes.";exit 0;fi
companions check_companion || fail "Optimized-file preflight failed."
mkdir -p "$EQDSP_BACKUP" || fail "Cannot create backup."
: >"$EQDSP_NEW_COMPANIONS" || fail "Cannot prepare operation log."
if [ -e "$EQDSP_BACKUP/original.apk" ]; then check_hash "$EQDSP_BACKUP/original.apk" "$EQDSP_ORIGINAL" || fail "Backup mismatch."
else cp "$EQDSP_PAYLOAD/original.apk" "$EQDSP_BACKUP/original.apk" || fail "Backup failed."; fi
check_hash "$EQDSP_BACKUP/original.apk" "$EQDSP_ORIGINAL" || fail "Backup verification failed."
echo "$EQDSP_TARGET" >"$EQDSP_BACKUP/target.txt"
ls -lZ "$EQDSP_TARGET" >"$EQDSP_BACKUP/metadata.txt"
sync
case "$EQDSP_TARGET" in /oem/*) EQDSP_MOUNT=/oem;; /system/*) EQDSP_MOUNT=/system;; *) fail "Unsupported partition.";; esac
mount -o remount,rw "$EQDSP_MOUNT" >/dev/null 2>&1 || :
EQDSP_PREV_OWNED=1
cp "$EQDSP_TARGET" "$EQDSP_TARGET.eqdsp-loudness-r1-prev" || fail "Cannot stage previous APK."
check_hash "$EQDSP_TARGET.eqdsp-loudness-r1-prev" "$EQDSP_BEFORE" || fail "Previous APK mismatch."
apk_permissions "$EQDSP_TARGET.eqdsp-loudness-r1-prev" || fail "Previous APK permissions failed."
EQDSP_STAGE_OWNED=1
cp "$EQDSP_PAYLOAD/$EQDSP_FOLDER" "$EQDSP_TARGET.eqdsp-loudness-r1-stage" || fail "Cannot stage APK."
check_hash "$EQDSP_TARGET.eqdsp-loudness-r1-stage" "$EQDSP_WANTED" || fail "Stage mismatch."
apk_permissions "$EQDSP_TARGET.eqdsp-loudness-r1-stage" || fail "Stage permissions failed."
sync
EQDSP_CHANGED=1
if [ "$EQDSP_BEFORE" != "$EQDSP_WANTED" ]; then EQDSP_MOVED=1;companions move_companion || fail "Optimized-file staging failed.";fi
mv -f "$EQDSP_TARGET.eqdsp-loudness-r1-stage" "$EQDSP_TARGET" || fail "APK rename failed."
/system/bin/restorecon "$EQDSP_TARGET" || fail "APK label failed."
check_hash "$EQDSP_TARGET" "$EQDSP_WANTED" || fail "APK commit mismatch."
sync
EQDSP_CHANGED=0;EQDSP_RESULT=SUCCESS
echo "SUCCESS: $EQDSP_MODE verified at $EQDSP_TARGET. Reboot using the updater."
exit 0
