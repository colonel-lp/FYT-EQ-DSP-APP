#!/system/bin/sh
# Removes the EQ & DSP privileged/system installation.

exec > /storage/sdcard1/eqdsp-system-uninstall.log 2>&1
set -x

echo "EQ & DSP system-app removal"
date
id
getprop ro.build.fingerprint
getprop ro.build.version.release

echo "--- System state before removal ---"
ls -ld /system/priv-app/EQDsp
ls -ld /system/priv-app/EQDspV114
ls -l /system/etc/permissions/privapp-permissions-com.eqdsp.controller.xml

echo "--- Remount /system read-write ---"
mount -o remount,rw /system
if [ $? -ne 0 ]; then
    echo "ERROR: /system remount failed"
    mount
    exit 1
fi

echo "--- Remove EQ & DSP system files ---"
rm -rf /system/priv-app/EQDsp
rm -rf /system/priv-app/EQDspV114
rm -f /system/etc/permissions/privapp-permissions-com.eqdsp.controller.xml
sync

echo "--- Verification ---"
ls -ld /system/priv-app/EQDsp
ls -ld /system/priv-app/EQDspV114
ls -l /system/etc/permissions/privapp-permissions-com.eqdsp.controller.xml

if [ -e /system/priv-app/EQDsp ] || [ -e /system/priv-app/EQDspV114 ] || [ -e /system/etc/permissions/privapp-permissions-com.eqdsp.controller.xml ]; then
    echo "ERROR: one or more EQ & DSP system files remain"
    exit 1
fi

echo "SUCCESS: EQ & DSP system app removed. Remove the USB drive so the Joying unit can reboot."
sync
