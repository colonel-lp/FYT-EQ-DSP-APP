#!/system/bin/sh
# r2, revised 2026-10-25. Static files and bounded read-only snapshots only.
# No pm/dumpsys/service calls, native-library loading, remounts or audio writes.
PATH=/system/bin:/system/xbin:/vendor/bin:/product/bin:/system_ext/bin${PATH:+:$PATH}
export PATH
EQDSP_USB=${1:-${0%/*}/..}
EQDSP_USB=$(CDPATH= cd "$EQDSP_USB" 2>/dev/null && pwd -P) || exit 2
[ -f "$EQDSP_USB/eqdsp-dsp-extractor/extract.sh" ] && [ -d "$EQDSP_USB/lsec_updatesh" ] || {
    echo "ERROR: choose the mounted USB root containing this extractor payload." >&2
    exit 2
}
EQDSP_STAMP=$(date +%Y%m%d-%H%M%S 2>/dev/null)
[ -n "$EQDSP_STAMP" ] || EQDSP_STAMP=run-$$
EQDSP_BASE=$EQDSP_USB/eqdsp-dsp-extract-r2-$EQDSP_STAMP
EQDSP_OUT=$EQDSP_BASE
EQDSP_SUFFIX=0
# Atomic mkdir prevents following an old/symlinked output directory.
while ! mkdir "$EQDSP_OUT" 2>/dev/null; do
    if [ ! -e "$EQDSP_OUT" ] && [ ! -L "$EQDSP_OUT" ]; then
        echo "ERROR: cannot create extractor output on $EQDSP_USB" >&2
        exit 1
    fi
    EQDSP_SUFFIX=$((EQDSP_SUFFIX+1))
    [ "$EQDSP_SUFFIX" -le 100 ] || { echo "ERROR: too many existing run names." >&2; exit 1; }
    EQDSP_OUT=$EQDSP_BASE-$EQDSP_SUFFIX
done
exec >"$EQDSP_OUT/extraction.log" 2>&1 || exit 1
EQDSP_FAILURES=0
EQDSP_WARNINGS=0
EQDSP_COPIED=0
EQDSP_APKS=0
EQDSP_MISSING=0
EQDSP_HASHER=
if command -v sha256sum >/dev/null 2>&1; then
    EQDSP_HASHER=sha256sum
elif command -v toybox >/dev/null 2>&1 && toybox sha256sum /dev/null >/dev/null 2>&1; then
    EQDSP_HASHER=toybox
elif command -v busybox >/dev/null 2>&1 && busybox sha256sum /dev/null >/dev/null 2>&1; then
    EQDSP_HASHER=busybox
else
    echo "WARNING: SHA-256 unavailable; copied bytes cannot be fingerprinted here."
    EQDSP_WARNINGS=$((EQDSP_WARNINGS+1))
fi
printf 'SOURCE\tOUTPUT\tSTATUS\n' >"$EQDSP_OUT/source-files.tsv" || exit 1
: >"$EQDSP_OUT/files.sha256" || exit 1
hash_file() {
    case "$EQDSP_HASHER" in
        sha256sum) sha256sum "$1" ;;
        toybox) toybox sha256sum "$1" ;;
        busybox) busybox sha256sum "$1" ;;
        *) return 1 ;;
    esac
}
copy_file() {
    if [ ! -f "$1" ]; then
        echo "NOT PRESENT: $1"
        EQDSP_MISSING=$((EQDSP_MISSING+1))
        return 0
    fi
    EQDSP_NAME=$(printf '%s\n' "$1" | sed 's#^/##;s#/#-#g')
    [ ! -f "$EQDSP_OUT/$EQDSP_NAME" ] || return 0
    echo "COPY: $1"
    ls -ldn "$1" 2>/dev/null
    if cp "$1" "$EQDSP_OUT/$EQDSP_NAME"; then
        EQDSP_COPIED=$((EQDSP_COPIED+1))
        case "$1" in *.apk) EQDSP_APKS=$((EQDSP_APKS+1));; esac
        printf '%s\t%s\tCOPIED\n' "$1" "$EQDSP_NAME" >>"$EQDSP_OUT/source-files.tsv" || EQDSP_FAILURES=$((EQDSP_FAILURES+1))
        if [ -n "$EQDSP_HASHER" ]; then
            (CDPATH= cd "$EQDSP_OUT" && hash_file "$EQDSP_NAME") >>"$EQDSP_OUT/files.sha256" || EQDSP_FAILURES=$((EQDSP_FAILURES+1))
        fi
    else
        EQDSP_FAILURES=$((EQDSP_FAILURES+1))
        printf '%s\t%s\tCOPY FAILED\n' "$1" "$EQDSP_NAME" >>"$EQDSP_OUT/source-files.tsv"
        rm -f "$EQDSP_OUT/$EQDSP_NAME"
    fi
}
copy_pattern() {
    EQDSP_MATCHED=0
    # Fixed script-owned patterns only; package/user input is never expanded here.
    for EQDSP_MATCH in $1; do
        [ -f "$EQDSP_MATCH" ] || continue
        EQDSP_MATCHED=1
        copy_file "$EQDSP_MATCH"
    done
    [ "$EQDSP_MATCHED" = 1 ] || echo "NO MATCH: $1"
}
copy_app_path() {
    case "$1" in
        */../*|*/./*|*/..|*/.) echo "REJECTED package traversal: $1"; EQDSP_WARNINGS=$((EQDSP_WARNINGS+1)); return;;
        /system/app/*|/system/priv-app/*|/system/system/app/*|/system/system/priv-app/*|\
        /vendor/app/*|/vendor/priv-app/*|/system/vendor/app/*|/system/vendor/priv-app/*|/oem/app/*|/oem/priv-app/*|\
        /product/app/*|/product/priv-app/*|/system_ext/app/*|/system_ext/priv-app/*|\
        /odm/app/*|/odm/priv-app/*|/system/product/app/*|/system/product/priv-app/*|\
        /system/system_ext/app/*|/system/system_ext/priv-app/*|/data/app/*|/mnt/expand/*/app/*) ;;
        *) echo "REJECTED non-app path: $1"; EQDSP_WARNINGS=$((EQDSP_WARNINGS+1)); return;;
    esac
    if [ -f "$1" ]; then
        case "$1" in *.apk) copy_file "$1";; esac
    elif [ -d "$1" ]; then
        for EQDSP_APP_FILE in "$1"/*.apk "$1"/lib/*/*.so \
            "$1"/oat/*/*.odex "$1"/oat/*/*.vdex; do
            [ ! -f "$EQDSP_APP_FILE" ] || copy_file "$EQDSP_APP_FILE"
        done
    else
        echo "NOT PRESENT package path: $1"
        EQDSP_WARNINGS=$((EQDSP_WARNINGS+1))
    fi
}
extract_package() {
    echo "SELECTED PACKAGE: $1"
    EQDSP_PACKAGE=$1
    EQDSP_PACKAGE_APKS_BEFORE=$EQDSP_APKS
    # Exact match; support multiline XML tags and factory updated-package entries.
    # The complete package database/global app inventory is never exported.
    EQDSP_PACKAGE_RE=$(printf '%s\n' "$EQDSP_PACKAGE" | sed 's/\./[.]/g')
    EQDSP_PATHS=
    if [ -r /data/system/packages.xml ]; then
        EQDSP_PATHS=$(sed -n "/<\(package\|updated-package\)\([[:space:]]\|$\)/{
            :entry
            />/!{N;b entry;}
            s/\n/ /g
            /[[:space:]]name=\"$EQDSP_PACKAGE_RE\"/{
                s/.*[[:space:]]codePath=\"\([^\"]*\)\".*/\1/p
            }
        }" /data/system/packages.xml) || {
            echo "WARNING: cannot parse selected package metadata."
            EQDSP_WARNINGS=$((EQDSP_WARNINGS+1))
        }
    fi
    if [ -n "$EQDSP_PATHS" ]; then
        while IFS= read -r EQDSP_APP_DIR; do
            [ -z "$EQDSP_APP_DIR" ] || copy_app_path "$EQDSP_APP_DIR"
        done <<EQDSP_PACKAGE_PATHS
$EQDSP_PATHS
EQDSP_PACKAGE_PATHS
    else
        echo "PACKAGE PATH NOT RESOLVED: $EQDSP_PACKAGE; trying selected filename matches only."
    fi
    # Retain named factory APKs when an active /data/app update is registered.
    for EQDSP_APP_BASE in /system /system/system /vendor /system/vendor /oem /product /system_ext /odm /system/product /system/system_ext; do
        for EQDSP_APP_DIR in "$EQDSP_APP_BASE"/app/*"$EQDSP_PACKAGE"* \
            "$EQDSP_APP_BASE"/priv-app/*"$EQDSP_PACKAGE"*; do
            [ -e "$EQDSP_APP_DIR" ] || continue
            case "$EQDSP_APP_DIR" in
                */"$EQDSP_PACKAGE"|*/"$EQDSP_PACKAGE.apk"|*_"$EQDSP_PACKAGE"|*_"$EQDSP_PACKAGE.apk")
                    copy_app_path "$EQDSP_APP_DIR" ;;
                *) echo "SKIPPED non-exact package filename: $EQDSP_APP_DIR" ;;
            esac
        done
    done
    if [ "$EQDSP_APKS" = "$EQDSP_PACKAGE_APKS_BEFORE" ]; then
        echo "NO APK COPIED for selected package: $EQDSP_PACKAGE"
        if [ "$EQDSP_PACKAGE" = com.syu.ms ]; then
            echo "WARNING: core FYT service APK missing; service patch analysis is incomplete."
            EQDSP_WARNINGS=$((EQDSP_WARNINGS+1))
        fi
    fi
}
echo "EQ & DSP read-only extractor r2; revision 2026-10-25; $(date)"
echo "USB: $EQDSP_USB"
echo "OUTPUT: $EQDSP_OUT"
echo "Offline updater snapshots do not establish active Android audio routing."
uname -m -r 2>/dev/null
if [ ! -r /data/system/packages.xml ]; then
    echo "WARNING: package metadata unavailable; encrypted/unmounted data is not mounted or unlocked."
    EQDSP_WARNINGS=$((EQDSP_WARNINGS+1))
fi
extract_package com.syu.ms
extract_package com.syu.eq
extract_package com.syu.av
for EQDSP_PART in /system /vendor /oem /product /system_ext /odm \
    /system/system /system/vendor /system/product /system/system_ext; do
    for EQDSP_BITS in lib lib64; do
        copy_pattern "$EQDSP_PART/$EQDSP_BITS/soundfx/*visualizer*.so"
        copy_pattern "$EQDSP_PART/$EQDSP_BITS/hw/audio*.so"
        for EQDSP_LIB in libmedia.so libaudioeffect_jni.so libaudioclient.so \
            libaudioflinger.so libaudiopolicyservice.so libaudiopolicymanagerdefault.so \
            libaudioutils.so libvbeffect.so libvbpga.so libdumpdata.so \
            libaudiomiscctl.so libAudioCustomMmi.so libfminterface.so \
            libFMHalSource.so libresample48kto44k.so libsqlcontrol.so libjni_spectrum.so; do
            copy_file "$EQDSP_PART/$EQDSP_BITS/$EQDSP_LIB"
        done
    done
    for EQDSP_CONFIG in '*audio*.conf' '*audio*.xml' 'mixer_paths*.xml' \
        'tiny_hw.xml' 'codec_pga.xml' 'audio_para' 'fyt.prop' 'prop.default'; do
        copy_pattern "$EQDSP_PART/etc/$EQDSP_CONFIG"
    done
    for EQDSP_CONFIG in "$EQDSP_PART"/etc/audio/*.xml "$EQDSP_PART"/etc/audio_policy/*.xml; do
        [ ! -f "$EQDSP_CONFIG" ] || copy_file "$EQDSP_CONFIG"
    done
    copy_file "$EQDSP_PART/build.prop"
    copy_file "$EQDSP_PART/default.prop"
    copy_pattern "$EQDSP_PART/framework/*syu*.jar"
    copy_pattern "$EQDSP_PART/framework/*fyt*.jar"
done
copy_file /default.prop
copy_file /oem/fyt.prop
copy_file /system/bin/audioserver
copy_file /proc/mounts
for EQDSP_PROC in /proc/asound/cards /proc/asound/pcm /proc/asound/devices /proc/asound/version; do
    copy_file "$EQDSP_PROC"
done
for EQDSP_CARD in /proc/asound/card[0-9]; do
    for EQDSP_PCM in "$EQDSP_CARD"/pcm[0-9]c "$EQDSP_CARD"/pcm[0-9]p; do
        for EQDSP_SUB in "$EQDSP_PCM"/sub[0-9]; do
            [ ! -d "$EQDSP_SUB" ] || { copy_file "$EQDSP_SUB/status"; copy_file "$EQDSP_SUB/hw_params"; }
        done
    done
done
echo "Sound-node metadata only (no device opened):"
ls -ldn /dev/snd /dev/snd/* /sys/class/sound/* 2>/dev/null
# -D selects a card and lists controls; no mixer value is supplied.
if command -v timeout >/dev/null 2>&1 && command -v tinymix >/dev/null 2>&1; then
    for EQDSP_CARD in 0 1; do
        EQDSP_MIXER=mixer-card$EQDSP_CARD.txt
        if (ulimit -f 64 && timeout -s KILL 3 tinymix -D "$EQDSP_CARD") >"$EQDSP_OUT/$EQDSP_MIXER" 2>&1; then
            echo "MIXER LISTED: card $EQDSP_CARD (updater context, not live playback evidence)"
        else
            echo "MIXER UNAVAILABLE/LIMITED: card $EQDSP_CARD"
            EQDSP_WARNINGS=$((EQDSP_WARNINGS+1))
        fi
        if [ -n "$EQDSP_HASHER" ]; then
            (CDPATH= cd "$EQDSP_OUT" && hash_file "$EQDSP_MIXER") >>"$EQDSP_OUT/files.sha256" || EQDSP_FAILURES=$((EQDSP_FAILURES+1))
        fi
    done
else
    echo "SKIPPED: mixer listing requires existing tinymix and timeout."
fi
[ "$EQDSP_APKS" -gt 0 ] || {
    echo "WARNING: no selected APK copied; service patch analysis is incomplete."
    EQDSP_WARNINGS=$((EQDSP_WARNINGS+1))
}
[ "$EQDSP_COPIED" -gt 0 ] || EQDSP_FAILURES=$((EQDSP_FAILURES+1))
EQDSP_EXIT=0
EQDSP_RESULT='COMPLETE: available selected inputs copied; inspect missing-file entries.'
if [ "$EQDSP_FAILURES" -ne 0 ] || [ "$EQDSP_WARNINGS" -ne 0 ]; then
    EQDSP_EXIT=1
    EQDSP_RESULT='PARTIAL: inspect warnings/failures before using this extraction.'
fi
{
    echo "$EQDSP_RESULT"
    echo "Copied files: $EQDSP_COPIED; APKs: $EQDSP_APKS; absent fixed paths: $EQDSP_MISSING"
    echo "Failures: $EQDSP_FAILURES; warnings: $EQDSP_WARNINGS"
    echo "Exit: $EQDSP_EXIT"
    echo "Output: $EQDSP_OUT"
    echo "No system files, DSP/mixer values, audio routing or dump properties were changed."
    echo "No raw audio, full package database, user settings or partition images collected."
    echo "Finished: $(date)"
} >"$EQDSP_OUT/RESULT.txt" || EQDSP_EXIT=1
cat "$EQDSP_OUT/RESULT.txt"
sync
exit "$EQDSP_EXIT"
