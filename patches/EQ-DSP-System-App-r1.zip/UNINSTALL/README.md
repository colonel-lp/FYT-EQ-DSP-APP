# EQ & DSP system-app uninstaller

This simple FYT/lsec script removes the privileged EQ & DSP installation from
the two system locations used by earlier builds:

- `/system/priv-app/EQDsp`
- `/system/priv-app/EQDspV114`
- `/system/etc/permissions/privapp-permissions-com.eqdsp.controller.xml`

It does not run Package Manager commands, make backups, remove public
`Download/eq-app` presets/themes, or alter separate DSP/Visualizer patches.

## USB preparation

1. Copy the `lsec_updatesh` folder to the USB root.
2. Add the known-compatible `lsec6521update` trigger file to the USB root.
3. Do not include another lsec launcher or firmware package on the same drive.
4. Run the update. When the log reports `SUCCESS`, remove the USB drive; the
   Joying unit will then reboot.
5. Install the new signed `EQDSP.apk` normally as a user app.

The log is written to `/storage/sdcard1/eqdsp-system-uninstall.log`.
