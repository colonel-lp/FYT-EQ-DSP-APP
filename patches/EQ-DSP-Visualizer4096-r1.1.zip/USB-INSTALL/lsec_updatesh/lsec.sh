#!/system/bin/sh
/system/bin/sh /storage/sdcard1/eqdsp-visualizer4096/run.sh install
