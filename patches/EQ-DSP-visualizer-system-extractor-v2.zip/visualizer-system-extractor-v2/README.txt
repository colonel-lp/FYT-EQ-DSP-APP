EQ & DSP fast read-only Visualizer extractor v2

This revision removes the command that stalled the first extraction:

  dumpsys media.audio_flinger

It also avoids every other dumpsys command and recursive filesystem search.
It copies the Visualizer/audio libraries, audio HALs, and all directly relevant
audio-policy XML fragments, then records only quick /proc and property reports.

It does not remount or modify /system, /vendor or /oem.

Copy these items to the USB root:

  lsec_updatesh/lsec.sh
  eqdsp-extractor-v2/extract-real.sh

The complete reference procedure includes lsec6521update. Keep it beside them and run the established update; it is not a universal trigger.
The script output is intentionally redirected to its log, so the update screen
will pause on the extract-real.sh command while it runs. It should normally
finish within one or two minutes, although slow USB storage may take longer.

Afterwards, return this complete folder from the USB:

  eqdsp-visualizer-extract-v2


Log: eqdsp-visualizer-extract-v2/eqdsp-system-extractor-v2.log on USB. Temporary working log: /cache/eqdsp-system-extractor-v2.log.
