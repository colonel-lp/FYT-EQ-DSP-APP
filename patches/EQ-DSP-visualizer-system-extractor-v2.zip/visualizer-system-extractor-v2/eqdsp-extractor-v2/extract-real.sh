#!/system/bin/sh
# Fast, read-only system inspection. Writes only to /cache and the USB stick.
# This revision deliberately avoids dumpsys and recursive find commands because
# media.audio_flinger blocked indefinitely on the tested Joying Android 8.1 unit.

USB=/storage/sdcard1
OUT=$USB/eqdsp-visualizer-extract-v2
LOG=/cache/eqdsp-system-extractor-v2.log

finish() {
    echo "--- extraction finished: $(date 2>/dev/null) ---"
    sync
    cp -f "$LOG" "$OUT/eqdsp-system-extractor-v2.log" 2>/dev/null
    sync
}

copy_one() {
    SOURCE_FILE=$1
    OUTPUT_NAME=$2
    if [ -f "$SOURCE_FILE" ]; then
        echo "COPY: $SOURCE_FILE"
        cp -f "$SOURCE_FILE" "$OUT/$OUTPUT_NAME"
    fi
}

copy_pattern_files() {
    for SOURCE_FILE in "$@"; do
        if [ ! -f "$SOURCE_FILE" ]; then continue; fi
        OUTPUT_NAME=$(echo "$SOURCE_FILE" | sed 's#^/##; s#/#-#g')
        copy_one "$SOURCE_FILE" "$OUTPUT_NAME"
    done
}

mkdir -p "$OUT" || exit 1
rm -f "$LOG"
exec >"$LOG" 2>&1
trap finish 0
set -x

echo "EQ & DSP Visualizer system-file extraction v2"
echo "Started: $(date 2>/dev/null)"
echo "No dumpsys, recursive search, remount or system modification is performed."

copy_pattern_files \
    /system/lib/soundfx/*visualizer*.so \
    /system/lib64/soundfx/*visualizer*.so \
    /vendor/lib/soundfx/*visualizer*.so \
    /vendor/lib64/soundfx/*visualizer*.so \
    /oem/lib/soundfx/*visualizer*.so \
    /oem/lib64/soundfx/*visualizer*.so

copy_pattern_files \
    /system/lib/libaudioeffect_jni.so \
    /system/lib64/libaudioeffect_jni.so \
    /system/lib/libmedia.so \
    /system/lib64/libmedia.so \
    /system/lib/libaudioclient.so \
    /system/lib64/libaudioclient.so \
    /system/lib/libaudioflinger.so \
    /system/lib64/libaudioflinger.so \
    /system/lib/libaudiopolicyservice.so \
    /system/lib64/libaudiopolicyservice.so \
    /system/lib/libaudiopolicymanagerdefault.so \
    /system/lib64/libaudiopolicymanagerdefault.so \
    /vendor/lib/libaudiopolicymanagerdefault.so \
    /vendor/lib64/libaudiopolicymanagerdefault.so

copy_pattern_files \
    /system/lib/hw/audio*.so \
    /system/lib64/hw/audio*.so \
    /vendor/lib/hw/audio*.so \
    /vendor/lib64/hw/audio*.so

# Copy all directly relevant configuration files, including the XML fragments
# referenced by audio_policy_configuration.xml.
copy_pattern_files \
    /system/etc/*audio*.conf \
    /system/etc/*audio*.xml \
    /system/etc/mixer_paths*.xml \
    /vendor/etc/*audio*.conf \
    /vendor/etc/*audio*.xml \
    /vendor/etc/mixer_paths*.xml \
    /oem/etc/*audio*.conf \
    /oem/etc/*audio*.xml \
    /oem/etc/mixer_paths*.xml

copy_one /system/bin/audioserver system-bin-audioserver
copy_one /system/build.prop system-build.prop
copy_one /vendor/build.prop vendor-build.prop
copy_one /oem/fyt.prop oem-fyt.prop

echo "Collecting quick non-blocking reports"
getprop > "$OUT/getprop.txt" 2>&1
cat /proc/mounts > "$OUT/proc-mounts.txt" 2>&1
cat /proc/asound/cards > "$OUT/proc-asound-cards.txt" 2>&1
cat /proc/asound/pcm > "$OUT/proc-asound-pcm.txt" 2>&1
cat /proc/asound/devices > "$OUT/proc-asound-devices.txt" 2>&1
cat /proc/asound/version > "$OUT/proc-asound-version.txt" 2>&1

echo "Extracted files:"
ls -l "$OUT"
if command -v md5sum >/dev/null 2>&1; then
    md5sum "$OUT"/* > "$OUT/md5sums.txt" 2>/dev/null
fi
echo "SUCCESS: fast read-only Visualizer extraction v2 completed."

