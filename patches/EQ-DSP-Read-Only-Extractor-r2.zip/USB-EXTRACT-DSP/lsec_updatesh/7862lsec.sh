#!/system/bin/sh
# Locate an existing payload only; never mount a partition or guess an updater.
EQDSP_LAUNCH_ROOT=
eqdsp_candidate() {
    [ -d "$1/lsec_updatesh" ] && [ -f "$1/eqdsp-dsp-extractor/extract.sh" ] || return 0
    EQDSP_LAUNCH_CANDIDATE=$(CDPATH= cd "$1" 2>/dev/null && pwd -P) || return 0
    if [ -n "$EQDSP_LAUNCH_ROOT" ] && [ "$EQDSP_LAUNCH_ROOT" != "$EQDSP_LAUNCH_CANDIDATE" ]; then
        echo "ERROR: multiple extractor USB roots found. Leave only one extractor USB connected." >&2
        exit 2
    fi
    EQDSP_LAUNCH_ROOT=$EQDSP_LAUNCH_CANDIDATE
}
case "$0" in
    */*) eqdsp_candidate "${0%/*}/.." ;;
esac
if [ -z "$EQDSP_LAUNCH_ROOT" ]; then
    [ -z "${1:-}" ] || eqdsp_candidate "$1"
fi
if [ -z "$EQDSP_LAUNCH_ROOT" ]; then eqdsp_candidate .; fi
if [ -z "$EQDSP_LAUNCH_ROOT" ]; then
    # The updater may run a temporary copy or supply the script via stdin.
    for EQDSP_LAUNCH_MOUNT in /storage/* /mnt/media_rw/* /mnt/usb_storage/* \
        /mnt/usb_storage /mnt/usb* /mnt/sdcard* /mnt/external_sd /udisk /usb; do
        eqdsp_candidate "$EQDSP_LAUNCH_MOUNT"
    done
fi
[ -n "$EQDSP_LAUNCH_ROOT" ] || {
    echo "ERROR: extractor payload not found. Copy the procedure contents to a mounted USB root." >&2
    exit 2
}
exec /system/bin/sh "$EQDSP_LAUNCH_ROOT/eqdsp-dsp-extractor/extract.sh" "$EQDSP_LAUNCH_ROOT"
