Visualizer 4096 r1.1 — install and restore

For the extracted FYT sp9853i_1h10 / sp9853i_1h10_vmm x86/x86_64 Android 8.1 (API 27) firmware ONLY. Exact original or already-patched hashes of all four libraries must match PATCH-MANIFEST.json. Unknown/unreadable files are not confirmed compatible. Do not run on Android 10/11 or a different firmware signature.

Use stable vehicle power and keep the correct firmware recovery package available. These procedures use the FYT lsec updater with root/system access, not Android's APK installer. ZIP download does not run any scripts.

Use a clean FAT32 USB drive. Copy the CONTENTS of ONE selected procedure folder to the USB root; never mix install, restore, uninstall or extractor launchers. Supply the compatible lsec6521update trigger from YOUR supported firmware/updater package at the USB root; it is not included. Do not substitute a trigger from another platform. Do not use firmware update images alongside these procedures. Insert USB and follow the supported unit's update procedure; do not interrupt power. Read the USB log after the reboot. A device model match alone does not establish compatibility.

INSTALL: copy contents of USB-INSTALL to USB root, add the correct trigger and run the supported updater. RESTORE: use USB-RESTORE instead. Scripts verify payload and device SHA-256 before writes, reject mismatches, back up originals to eqdsp-visualizer4096-backup-r1 on USB, stage replacements, verify committed files and roll back on failure. Keep the backup, original payload and restore procedure. A failed restore or boot failure needs the correct firmware recovery procedure.

Changes /system/lib/libmedia.so, /system/lib64/libmedia.so and both /vendor/lib*/soundfx/libvisualizer.so. Allows opt-in waveform capture up to 4096; the advertised default remains 1024 and native FFT is guarded above 1024. The app performs its own FFT. Replacing audio libraries may prevent boot/audio if incompatible. Installer rechecks signatures at execution time, even after the app checks them. On rejection, use the read-only extractor and submit reviewed output; do not bypass checks.
