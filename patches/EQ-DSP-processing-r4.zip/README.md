# Processing r4 — read-only chip analyser / installer 9

- Adds a fixed read-only 16-band analyser endpoint to Processing r3. Existing filter bank protocol 2, Loudness, verification waits, persistence and routing behavior are retained.
- Companion controller: **1.69-beta / build 90**, source only. The app selects Android Visualizer, stock seven-band callbacks, this full-band endpoint, existing warned policy trials or an Android-advertised line input.
- No detailed Line In PCM or DSP digital-return path is claimed. The 16 bands are coarse and pre-EQ. Raw bytes are retained in Diagnostics; display decoding follows the stock driver's byte assembly and requires unit comparison.
- The new signed APK is delivered by local download for owner upload. See `UPLOAD-REQUIRED.md`; INSTALL refuses a missing or incorrect APK. No ZIP or controller APK is generated.

## Procedures

1. Prepare RESTORE first and retain working firmware recovery files. Copy the contents of one procedure folder to USB root, including the known `lsec6521update`; do not combine launchers.
2. Run CHECK through the existing offline updater procedure. Exact factory, earlier known patches and Processing r3 hashes are accepted. Unknown APKs stop the procedure.
3. Run INSTALL separately, reboot and retain `eqdsp-processing-r4-install.log`. File/signature checks do not establish audio behavior.
4. Update the controller from the 1.69 source using your existing app signing identity. Select **CHIP 16 BANDS** in Settings after the capability probe completes. Check Diagnostics while playing a known Line In tone, Android tone and silence. Compare stock seven-band values with raw/full-band values. Check speaker playback and DSP controls.
5. RESTORE uses the exact factory service APK and removes both service extensions. To return specifically to r3, restore factory first, then use the prior r3 INSTALL. Keep service/app data and existing actual-device backups; a factory service cannot implement the extensions stored by newer controllers.

| Procedure | APK payload | USB log |
| --- | --- | --- |
| USB-CHECK | None | `eqdsp-processing-r4-check.log` |
| USB-INSTALL | `eqdsp-loudness/patched.apk` only | `eqdsp-processing-r4-install.log` |
| USB-RESTORE | `eqdsp-loudness/original.apk` only | `eqdsp-processing-r4-restore.log` |

The existing package-path/profile/hash, signing, backup, permissions, optimized-file and rollback guards remain. Both mutation procedures preserve exact pre-operation files in immutable hash-named USB snapshots. Do not bypass a mismatch or rollback failure.

## Analyser protocol 1

- Sound command **0x455113**, callback **119**, magic **0x45515331**. Callback 119 is unused by the inspected stock dispatcher and is within its 128-entry registration table.
- Request: `[magic, 1, positiveToken, operation]`; operation **0=capability**, **1=single read**. Exact length 4; no float/string arguments. Caller must be system UID or the existing authorized controller package.
- Reply prefix (9 integers): `[magic, 1, serviceInstance, token, status, DSPsampleRate, selector0203, byteFormat, byteCount]`. `byteFormat=0` means raw unsigned bytes in stock transport order. Capability success has zero bytes; read success has 32 bytes, total **41 integers**.
- Status: **0=success, 2=busy, 3=denied, 5=unavailable, 8=read failure**. Invalid requests are consumed without hardware access. Capability checks use cached profile/rate, not bus reads.
- Reads run on the existing device handler under `d.ap`, at most one queued. The only read destinations are **0x0203 (one byte)** and **0xA000 (32 bytes)**. Reads skip setup, startup verification and live Processing transactions. No selector, attenuation, coefficient, sample-rate or routing write is permitted.
- The app issues at most one request at a time, polls only the selected full-band source in the foreground at up to 5 Hz, uses a 1.2-second reply deadline and restores a previous safe source after 2.5 seconds without fresh chip data. Capability replies and late frames are token/instance checked. Backgrounding stops polling and capture.
- Legacy seven-band callbacks continue unchanged. The endpoint does **not** call `C32107.c()`, whose stock spectrum routine also performs silence-muting writes.

## Build and evidence

- Use the existing `tools/loudness-service/build.py` recipe with the exact factory APK, matching retained key/certificate, Apktool 2.12.1 and build tools 35.0.0. Keys and local SDK paths are never committed.
- `tools/loudness-service/package.py` prepares these three current procedure folders. No archive is created.
- Focused service/client/display/PCM checks: `python3 tools/tests/audio-capture/run-service.py`; controller test sources are alongside it. Full app source compilation is separate from device or APK validation.
- The read-only [audio-capture probe](../audio-capture-probe/README.md) supplies missing configs, `libdumpdata` and live status for further I²S/HAL analysis. Continuous sources remain unavailable until a compatible route is established.
